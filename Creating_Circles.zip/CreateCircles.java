/*
Jessica Montoya
9/14/20
IT 206-202
Assignment 2
In this program, the user will input information for one or many circles. The information the user will input for the circle will include its x position, y position, radius, and color.
Once the user has finished entering the information, the program will take the information and display one more many circles on the screen. The circles will appear the with characteristics
the user has assigned to it.
*/

import javax.swing.JOptionPane;

public class CreateCircles {

   //This method calls different methods to create circles. Once that is done, it calls the method to display the circles on the screen.
   public static void main(String[] args) {
        //initialize the CircleDrawer class
        CircleDrawer cd = new CircleDrawer();
        
        //Initiate the loop that continuously prompts the user for values until the user decides to end it 
        promptUser(cd);
        
		  //display the CircleDrawer application
        cd.show();
   }
   
   /*
   Continuously prompts the user for circle information to make circles from the information. The user decides when to stop inputting information.
   
   @param cd an object that takes in circle information, so it knows how to display circles in the end result
   */
   public static void promptUser(CircleDrawer cd) {
      boolean done = false;
      boolean moveOn = false;
      boolean firstRun = true;
      String checkDone;
      int count = 0;
      int newX = 0;
      int newY = 0;
      int newR = 0;
      String newC = "";
      
      while (!done) {
         count += 1;
         
         //Ensures there is information entered for at least one circle. After one circle has information, the user can end the prompting at any time.
         if (firstRun) {
            //Validating x to make sure it is numeric
            while (!moveOn){
               try {
                  newX = Integer.parseInt(JOptionPane.showInputDialog("Circle #" + count + ":\nEnter a value for the x position\n(Between 0 and 800)"));
                  moveOn = true;
               }
               catch (NumberFormatException e) {
                  JOptionPane.showMessageDialog(null, "Error. Enter a numeric value");
                  moveOn = false;
               }
            }
         }
         else {
            //Validating x to make sure it is numeric
            while (!moveOn){
               checkDone = JOptionPane.showInputDialog("Circle #" + count + ":\nEnter a value for the x position. Enter 'finish' to end\n(Between 0 and 800)");
            
               //Check to see if the user wants to end the prompts
               if (checkDone.equalsIgnoreCase("finish")) {
                  done = true;
                  moveOn = true;
               }
               else {
                  try {
                     newX = Integer.parseInt(checkDone);
                     moveOn = true;
                  }
                  catch (NumberFormatException e) {
                     JOptionPane.showMessageDialog(null, "Error. Enter a numeric value");
                     moveOn = false;
                  }
               }
            }
         }
         
         moveOn = false;
         
         //Run this code when the user decides that they want to continue entering information
         if (!done || firstRun) {
            
            //Validating y to make sure it is a numeric value
            while (!moveOn){
               try {
                  newY = Integer.parseInt(JOptionPane.showInputDialog("Enter a value for the y position\n(Between 0 and 600)"));
                  moveOn = true;
               }
               catch (NumberFormatException e) {
                  JOptionPane.showMessageDialog(null, "Error. Enter a numeric value");
                  moveOn = false;
               }
            }
            moveOn = false;
            
            //Validating r to make sure it is a numeric value
            while (!moveOn){
               try {
                  newR = Integer.parseInt(JOptionPane.showInputDialog("Enter a value for the radius\n(Between 0 and 100)"));
                  moveOn = true;
               }
               catch (NumberFormatException e) {
                  JOptionPane.showMessageDialog(null, "Error. Enter a numeric value");
                  moveOn = false;
               }
            }
            moveOn = false;
         
            newC = JOptionPane.showInputDialog("Enter a color");
            sendCircleInfo(cd, newX, newY, newR, newC);
            firstRun = false;
         }
      }
   }
   
   /*
   Sends the information entered for one circle to different files to have them processed.
   
   @param cd an object that takes in circle information, so it knows how to display circles in the end result
   @param xValue the number that will be given to a circle for its x position
   @param yValue the number that will be given to a circle for its y position
   @param rValue the number that will be given to a circle for its radius
   @param cValue will define the color for a circle with a string
   */
   private static void sendCircleInfo(CircleDrawer cd, int xValue, int yValue, int rValue, String cValue) {
      //Create a circle with the values provided by the user
      Circle newC = new Circle(xValue, yValue, rValue, cValue);
      
      //add the Circles to the CircleDrawer
      cd.addCircle(newC);
   }
}