/*
Jessica Montoya
9/8/20
IT 206-202
Assignment 2
In this program, the user will input information for one or many circles. The information the user will input for the circle will include its x position, y position, radius, and color.
Once the user has finished entering the information, the program will take the information and display one more many circles on the screen. The circles will appear the with characteristics
the user has assigned to it.
*/

import javax.swing.JOptionPane;

public class Circle {
   private int x;
   private int y;
   private int radius;
   private String color;
   
   /*
   Constructs a circle with a specified x, y, radius, and color. Also handles validation for each variable.
   
   @param cd an object that takes in circle information, so it knows how to display circles in the end result
   @param xValue the number that will be given to a circle for its x position
   @param yValue the number that will be given to a circle for its y position
   @param rValue the number that will be given to a circle for its radius
   @param cValue will define the color for a circle with a string
   */
   public Circle(int xValue, int yValue, int rValue, String cValue) {
      final String[] allowedColors = {"red", "green", "blue"};
      final int min = 0;
      final int xMax = 800;
      final int yMax = 600;
      final int rMax = 100;
      
      //Validating the x value
      if (xValue >= min && xValue <= xMax) {
         setX(xValue);
      }
      else {
         //Prompt for a new x value when the x value is not acceptable.
         while (xValue < min || xValue > xMax) {
            xValue = Integer.parseInt(JOptionPane.showInputDialog("Error. X value must be between 0 and 800"));
         }
         setX(xValue);
      }
      
      //Validating the y value
      if (yValue >= min && yValue <= yMax) {
         setY(yValue);
      }
      else {
         //Prompt for a new y value when the y value is not acceptable.
         while (yValue < min || yValue > yMax) {
            yValue = Integer.parseInt(JOptionPane.showInputDialog("Error. Y value must be between 0 and 600"));
         }
         setY(yValue);
      }
      
      //Validating the radius
      if (rValue > min && rValue <= rMax) {
         setRadius(rValue);
      }
      else {
         //Prompt for a new radius when the radius is not acceptable.
         while (rValue <= min || rValue > rMax) {
            rValue = Integer.parseInt(JOptionPane.showInputDialog("Error. The radius must be between 0 and 100"));
         }
         setRadius(rValue);
      }
      
      boolean setColor = false;
      
      //Validate the color
      setColor = checkColor(cValue.toLowerCase(), allowedColors);
      
      //Prompt for a new color if color is not accepted
      if (!setColor) {
         String output = "Error. The circle must be one of the following colors:";
         for (int i = 0; i < allowedColors.length; i++) {
            output += ("\n" + allowedColors[i]);
         }
         
         while (!setColor) { 
            cValue = JOptionPane.showInputDialog(output);
            setColor = checkColor(cValue.toLowerCase(), allowedColors);
         }
      }
   }
   
   /*
   Checks to see if the provided color is a part of the acceptable colors listed in the accepted colors array.
   
   @param newColor will define the color for a circle with a string
   @param allowedColors the array that lists all the colors that can be used to display the circle(s)
   
   @return a boolean that states if the color is acceptable
   */
   private boolean checkColor(String newColor, String[] allowedColors) {
      boolean result = false;
      
      //Loops through all the strings in the array and compares it to the value provided by the user
      for (int i= 0; i < allowedColors.length; i++) {
         if (newColor.equals(allowedColors[i])) {
            setColor(newColor);
            result = true;
         }
      }
      
      return result;
   }
   
   /*
   Sets the x attribute of the circle to the value the user has provided
   
   @param newX the number that will be given to a circle for its x position
   */
   private void setX(int newX) {
      this.x = newX;
   }
   
   /*
   Sets the y attribute of the circle to the value the user has provided
   
   @param newY the number that will be given to a circle for its y position
   */
   private void setY(int newY) {
      this.y = newY;
   }
   
   /*
   Sets the radius attribute of the circle to the value the user has provided
   
   @param newRadius the number that will be given to a circle for its radius
   */
   private void setRadius(int newRadius) {
      this.radius = newRadius;
   }
   
   /*
   Sets the color attribute of the circle to the value the user has provided
   
   @param newColor will define the color for a circle with a string
   */
   private void setColor(String newColor) {
      this.color = newColor;
   }
   
   //Sends the value of the x attribute back to the method caller
   public int getX() {
      return this.x;
   }
   
   //Sends the value of the y attribute back to the method caller
   public int getY() {
      return this.y;
   }
   
   //Sends the value of the radius attribute back to the method caller
   public int getRadius() {
      return this.radius;
   }
   
   //Sends the value of the color attribute back to the method caller
   public String getColor() {
      return this.color;
   }
   
   //Sends a string listing all the values for all the circle's attributes back to the method caller
   public String toString() {
      return "This circle's x position: " + this.x + 
      "\nThis circle's y position: " + this.y +
      "\nThis circle's radius: " + this.radius +
      "\nThis circle's color: " + this.color;
   }

}