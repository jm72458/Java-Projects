import java.awt.*;
import javax.swing.*;
import java.util.*;

public class CircleDrawer {
   // height and width of the screen
   private int height = 600;
   private int width = 800;
   private JFrame f;
   private ArrayList<Circle> circles;

   //Constructs a display where the circles are going to appear
   public CircleDrawer() {
      f = new JFrame("CircleDrawer");
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      circles = new ArrayList<Circle>();
   }

   //Display all the circles onto a separate window
   public void show() {
      JPanel p = new JPanel() {
          public void paintComponent(Graphics g) {
              for (Circle c: circles) {
                  if (c.getColor().equals("red")) {
                    g.setColor(Color.red);
                  }
                  if (c.getColor().equals("green")) {
                    g.setColor(Color.green);
                  }
                  if (c.getColor().equals("blue")) {
                    g.setColor(Color.blue);
                  }
                  int newx = c.getX() - c.getRadius();
                  int newy = c.getY() - c.getRadius();
                  g.fillOval(newx, newy, c.getRadius(), c.getRadius());
              }
          }
      };
      p.setPreferredSize(new Dimension(width, height));
      f.getContentPane().add(p);
      f.pack();
      f.show();

   }

   /*
   Adds circle objects into an array
   
   @param c a circle object that has attributes associated with it to give it characteristics
   */
   public void addCircle(Circle c) {
      // later on, we will see why this is a bad idea!
      circles.add(c);      
   }
}
