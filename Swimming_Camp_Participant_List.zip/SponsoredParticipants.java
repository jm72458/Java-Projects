/*
Jessica Montoya
10/12/20
IT 206-202
Assignment 6
In this program, the user will input information for one or many participants in a swimming camp. The information the user will input for a participant will include the participant's name, age, sex,
phone number, and email address. If the participant is sponsored it will also include its organization and percentage discount. The program uses this information to create a list of registered participants and enroll them into
classes offered by the swimming camp. This program is designed to be flexible in terms of the number of participants that can be enrolled in the swimming camp. This flexibility was added in case changes needed to be done to
the program in the future.
*/

public class SponsoredParticipants extends Participants {
   private String organization;
   private int percentageDiscount;
   
   public SponsoredParticipants(String newName, int newAge, char newSex, String newCellPhoneNumber, String newEmailAddress, String newOrganization, int newPercentageDiscount) {
      super(newName, newAge, newSex, newCellPhoneNumber, newEmailAddress);
      this.organization = newOrganization;
      this.percentageDiscount = newPercentageDiscount;
   }
   
   /*
   When called it removes information on a specific participant.
   */
   public void removeParticipant() {
      super.removeParticipant();
      this.organization = "";
      this.percentageDiscount = -1;
   }
   
   /*
   When called it displays information on a participant's name, age, sex, cell phone number, email address, organization, and billed price rate
   for a specific participant. It will also display the participant's enrolled zone, enrolled classes, and billed price rate if the participant
   is enrolled in one or more classes.
   
   @return an string that displays information on a a participant's name, age, sex, cell phone number, email address, organization, and billed
   price rate for a specific participant. Also displays the participant's enrolled zone, enrolled classes, and billed price rate if the participant
   is enrolled in one or more classes.
   */
   public String toString() {
      String report = "Name: " + super.getName();
      report += "\nAge: " + super.getAge();
      report += "\nSex: " + Character.toUpperCase(super.getSex());
      report += "\n\nCell Phone Number:\n" + super.getCellPhoneNumber();
      report += "\n\nEmail Address:\n" + super.getEmailAddress();
      
      report += "\n\nOrganization: " + this.organization;
      report += "\nPercentage Discount: " + this.percentageDiscount + "%";
      
      //Only add to report if the participant has been enrolled in classes
      String[] enrolledClasses = null;
      
      try {
         enrolledClasses = super.getEnrolledClasses();
         
         if (enrolledClasses[0] != null){
            report += "\n\nEnrolled Classes:\n";
         
            for (int i = 0; i < enrolledClasses.length; i++) {
               if (enrolledClasses[i] != null) {
                  if (i == 0) {
                     report += " " + enrolledClasses[i];
                  }
                  else {
                     report += ", " + enrolledClasses[i];
                  }
               }
            }
         
            report += "\n\nZone: " + super.getEnrolledZone();
            
            double dividedDiscount = this.percentageDiscount/100.0;
            report += "\nBilled Price Rate: $" + (super.getBilledPriceRate() - (super.getBilledPriceRate() * dividedDiscount)) + "0";
         }
      }
      catch (NullPointerException e) {
         report += "\n\n" + super.getName() + " has not been enrolled in classes.";
      }
      
      report += "\n\n";
      
      return report;
   }
}