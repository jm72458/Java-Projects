/*
Jessica Montoya
10/12/20
IT 206-202
Assignment 6
In this program, the user will input information for one or many participants in a swimming camp. The information the user will input for a participant will include the participant's name, age, sex,
phone number, and email address. If the participant is sponsored it will also include its organization and percentage discount. The program uses this information to create a list of registered participants and enroll them into
classes offered by the swimming camp. This program is designed to be flexible in terms of the number of participants that can be enrolled in the swimming camp. This flexibility was added in case changes needed to be done to
the program in the future.
*/

public class Participants {
   private String name;
   private int age;
   private char sex;
   private String cellPhoneNumber;
   private String emailAddress;
   private String[] enrolledClasses;
   private String enrolledZone;
   private double billedPriceRate;
   public static int numOfParticipants = 0;
   
   /*
   Constructs a participant with a specified name, age, sex, cell phone number, and email address.
   
   @param newName the string that will be given to a participant for its name.
   @param newAge the integer that will be given to a participant for its age.
   @param newSex the char that will be given to a participant for its sex.
   @param newCellPhoneNumber the string that will be given to a participant for its cell phone number.
   @param newEmailAddress the string that will be given to a participant for its email address.
   */
   public Participants(String newName, int newAge, char newSex, String newCellPhoneNumber, String newEmailAddress) {
      //Setting name to title case
      String firstLetter = newName.substring(0,1).toUpperCase();
      String restOfName = newName.substring(1, newName.length()).toLowerCase();
      newName = firstLetter.concat(restOfName).trim();
      
      //If the user entered more parts to the name instead of entering only the first name then captialize each part
      if (newName.indexOf(' ') > -1) {
         String upperCharacter;
         String section = "";
         String name = "";
         int lastIndex = -2;
         
         for (int i = 0; i < (newName.length() - 1); i++) {
            if (newName.charAt(i) == ' '){
               section = newName.substring(lastIndex + 2, i + 1);
               upperCharacter = newName.substring(i+1, i+2).toUpperCase();
               name += section.concat(upperCharacter);
               lastIndex = i;
            }
         }
         
         if (lastIndex + 2 < newName.length()) {
            section = newName.substring(lastIndex + 2, newName.length());
            name = name.concat(section);
         }
         
         newName = name;
      }

      this.name = newName;
      this.age = newAge;
      this.sex = newSex;
      this.cellPhoneNumber = newCellPhoneNumber;
      this.emailAddress = newEmailAddress;
      this.enrolledClasses = null;
      this.enrolledZone = "";
      numOfParticipants++;
   }
   
   /*
   When called it returns the name of that specific participant.
   
   @return a string that represents the name of a participant.
   */
   public String getName() {
      return this.name;
   }
   
   /*
   When called it returns the age of that specific participant.
   
   @return an integer that represents the age of a participant.
   */
   public int getAge() {
      return this.age;
   }
   
   /*
   When called it returns the sex of that specific participant.
   
   @return a char that represents the sex of a participant.
   */
   public char getSex() {
      return this.sex;
   }
   
   /*
   When called it returns the cell phone number of that specific participant.
   
   @return a string that represents the cell phone number of a participant.
   */
   public String getCellPhoneNumber() {
      return this.cellPhoneNumber;
   }
   
   /*
   When called it returns the email address of that specific participant.
   
   @return a string that represents the email address of a participant.
   */
   public String getEmailAddress() {
      return this.emailAddress;
   }
   
   /*
   When called it returns the enrolled classes of that specific participant.
   
   @return a string array that represents the enrolled classes of a participant.
   */
   public String[] getEnrolledClasses() {
      String[] participantClasses = null;
      
      if (this.enrolledClasses != null) {
         participantClasses = new String[this.enrolledClasses.length];
         for (int i = 0; i < this.enrolledClasses.length; i++) {
            participantClasses[i] = enrolledClasses[i];
         }
      }
      
      return participantClasses;
   }
   
   /*
   When called it returns the enrolled zone of that specific participant.
   
   @return a string that represents the enrolled zone of a participant.
   */
   public String getEnrolledZone() {
      return this.enrolledZone;
   }
   
   /*
   When called it returns the billed price rate of that specific participant.
   
   @return a string that represents the bill price rate of a participant.
   */
   public double getBilledPriceRate() {
      return this.billedPriceRate;
   }
   
   /*
   When called it changes the zone information for a specific participant.
   
   @param newZone a string that will change the zone of a specific participant.
   */
   public void setEnrolledZone(String newZone) {
      this.enrolledZone = newZone;
   }
   
   /*
   When called it changes the zone information for a specific participant.
   
   @param newClasses a string array that will change the enrolled classes of a specific participant.
   */
   public void setEnrolledClasses(String[] newClasses) {
      String[] enrolledClasses = new String[newClasses.length];
      
      for (int i = 0; i < enrolledClasses.length; i++){
         enrolledClasses[i] = newClasses[i];
      }
      
      this.enrolledClasses = enrolledClasses;
   }
   
   /*
   When called it changes the billed price information for a specific participant.
   
   @param newClasses a string array that will change the billed price rate of a specific participant.
   */
   public void setBilledPriceRate(double newBilledPriceRate){
      this.billedPriceRate = newBilledPriceRate;
   }

   /*
   When called it returns the number of registered participants.
   
   @return an integer that represents the number of registered participants.
   */
   public static int getNumOfParticipants() {
      return numOfParticipants;
   }
   
   /*
   When called it removes information on a specific participant.
   */
   public void removeParticipant() {
      this.name = "";
      this.age = -1;
      this.sex = ' ';
      this.cellPhoneNumber = "";
      this.emailAddress = "";
      try {
         for (int i = 0; i < this.enrolledClasses.length; i++) {
            this.enrolledClasses[i] = "";
         }
      }
      catch(NullPointerException e){
         System.out.println("The participant is not enrolled in classes");
      }
      numOfParticipants--;
   }
   
   /*
   When called it displays information on a participant's name, age, sex, cell phone number, and email address for a specific participant.
   It will also display the participant's enrolled zone, enrolled classes, and billed price rate if the participant is enrolled in one or
   more classes.
   
   @return an string that displays information on a a participant's name, age, sex, cell phone number, and email address for a specific participant.
   Also displays the participant's enrolled zone, enrolled classes, and billed price rate if the participant is enrolled in one or more classes.
   */
   public String toString() {
      String report = "Name: " + this.name;
      report += "\nAge: " + this.age;
      report += "\nSex: " + Character.toUpperCase(this.sex);
      report += "\n\nCell Phone Number:\n" + this.cellPhoneNumber;
      report += "\n\nEmail Address:\n" + this.emailAddress;
      
      //Only add to report if the participant has been enrolled in classes
      try {
         if (this.enrolledClasses[0] != null){
            report += "\n\nEnrolled Classes:\n";
         
            for (int i = 0; i < enrolledClasses.length; i++) {
               if (enrolledClasses[i] != null) {
                  if (i == 0) {
                     report += " " + enrolledClasses[i];
                  }
                  else {
                     report += ", " + enrolledClasses[i];
                  }
               }
            }
         
            report += "\n\nZone: " + this.enrolledZone;
            report += "\nBilled Price Rate: $" + this.billedPriceRate + "0";
         }
      }
      catch (NullPointerException e) {
         report += "\n\n" + this.name + " has not been enrolled in classes.";
      }
      
      report += "\n\n";
      
      return report;
   }
}