/*
Jessica Montoya
10/12/20
IT 206-202
Assignment 6
In this program, the user will input information for one or many participants in a swimming camp. The information the user will input for a participant will include the participant's name, age, sex,
phone number, and email address. If the participant is sponsored it will also include its organization and percentage discount. The program uses this information to create a list of registered participants and enroll them into
classes offered by the swimming camp. This program is designed to be flexible in terms of the number of participants that can be enrolled in the swimming camp. This flexibility was added in case changes needed to be done to
the program in the future.
*/

public class Classes {
   private String name;
   private double cost;
   public static int numOfClasses = 0;
   
   /*
   Constructs a class with a specified name and cost.
   
   @param name the string that will be given to a class for its name.
   @param cost the number that will be given to a class for its cost.
   */
   public Classes(String name, double cost) {
      this.name = name;
      this.cost = cost;
      numOfClasses++;
   }
   
   /*
   When called it returns the name of that specific class.
   
   @return a string that represents the name of a class.
   */
   public String getName() {
      return this.name;
   }
   
   /*
   When called it returns the cost of that specific class.
   
   @return a number that represents the cost of a class.
   */
   public double getCost() {
      return this.cost;
   }
   
   /*
   When called it returns the number of classes that are available to participants in the swimming camp.
   
   @return an integer that represents the number of available classes in the swimming camp.
   */
   public static int getNumOfClasses() {
      return numOfClasses;
   }
}