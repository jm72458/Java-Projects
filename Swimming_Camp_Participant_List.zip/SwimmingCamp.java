/*
Jessica Montoya
10/12/20
IT 206-202
Assignment 6
In this program, the user will input information for one or many participants in a swimming camp. The information the user will input for a participant will include the participant's name, age, sex,
phone number, and email address. If the participant is sponsored it will also include its organization and percentage discount. The program uses this information to create a list of registered participants and enroll them into
classes offered by the swimming camp. This program is designed to be flexible in terms of the number of participants that can be enrolled in the swimming camp. This flexibility was added in case changes needed to be done to
the program in the future.
*/

import javax.swing.JOptionPane;

public class SwimmingCamp {
   public static void main(String[] args){
      final int MAX_PARTICIPANTS = 60;
      final int NUM_OF_CLASSES = 4;
      final int MAX_CLASSES = 3;
      final int MAX_AGE = 18;
      final int MIN_AGE = 10;
      final String[] ALL_ZONES = {"EAST", "WEST", "NORTH", "SOUTH"};
      
      //Create objects for all the different classes through hardcoding
      Classes[] allClasses = new Classes[NUM_OF_CLASSES];
      createClasses(allClasses);
      Participants[] allParticipants = new Participants[MAX_PARTICIPANTS];
      promptUser(allParticipants, allClasses, MAX_AGE, MIN_AGE, MAX_CLASSES, ALL_ZONES, MAX_PARTICIPANTS);
   }
   
   /*
   Hardcoded class information in with their associated prices.
   
   @param allClasses an array of objects that takes in Class information that will be later used for retrieving class information and validating user input.
   */
   public static void createClasses(Classes[] allClasses) {
      allClasses[0] = new Classes("Freestyle", 100);
      allClasses[1] = new Classes("Breaststroke", 100);
      allClasses[2] = new Classes("Backstroke", 100);
      allClasses[3] = new Classes("Butterfly", 150);
   }
   
   /*
   Continuously prompts the user for a menu option that can register a participant, enroll a participant, remove an enrolled participant,
   print a participant record, or exit the program. The user decides when the prompting should stop.
   
   @param allParticipants an array of objects that takes in participant information to enroll participants into classes.
   @param allClasses an array of objects that is used to retrieve class information and validate user input.
   @param maxAge an integer that is used to limit the oldest age a participant can be to register in swimming camp.
   @param minAge an integer that is used to limit the youngest age a participant can be to register in swimming camp.
   @param maxClasses an integer that is used to limit the max number of classes a participant can enroll into.
   @param allZones an array that is used to retrieve zone information.
   */
   public static void promptUser(Participants[] allParticipants, Classes[] allClasses, int maxAge, int minAge, int maxClasses, String[] allZones, int maxParticipants) {
      String userInput;
      boolean done = false;
      
      final String REPORT = "Select one of the following options:\n\n1. Register\n2. Enroll\n3. Remove Enrolled Participant\n4. Print Participant Record\n5. Quit";
      
      //Continously show the menu until the user decides to quit the program
      while (!done) {
         userInput = JOptionPane.showInputDialog(REPORT);
         
         //Handling all the menu choices
         switch(userInput.trim().toLowerCase()) {
            case "1":
            case "register": registerParticipant(allParticipants, maxAge, minAge, maxParticipants); break;
            case "2":
            case "enroll": enrollParticipant(allParticipants, allClasses, maxClasses, allZones); break;
            case "3":
            case "remove enrolled participant": removeEnrolledParticipant(allParticipants); break;
            case "4":
            case "print participant record": printParticipantRecord(allParticipants); break;
            case "5":
            case "quit": JOptionPane.showMessageDialog(null, "Thank you for using this program!");
                         done = true; break;
            default: JOptionPane.showMessageDialog(null, "Error. Please enter the number or the name associated with each menu option."); break;
         }
      }
   }
   
   /*
   Prompts the user for information on a partcipant. Prompt for information such as the participant's name, age, sex, phone number,
   and email address. If the participant is sponsored it will also prompt for an organization name and percentage discount.
   
   @param allParticipants an array of objects that takes in participant information.
   @param maxAge an integer that is used to limit the oldest age a participant can be to register in swimming camp.
   @param minAge an integer that is used to limit the youngest age a participant can be to register in swimming camp.
   */
   public static void registerParticipant(Participants[] allParticipants, int maxAge, int minAge, int maxParticipants) {
      boolean moveOn = false;
      String userInput;
      String name = "";
      int age = -1;
      char sex = ' ';
      String phoneNumber = "";
      String emailAddress = "";
      String organization = "";
      int percentageDiscount = 0;
      final String MENU_TITLE = "Register:\n\n";
      
      //Checking to see if max number of registered participants has been reached
      if (Participants.getNumOfParticipants() == maxParticipants) {
         JOptionPane.showMessageDialog(null, MENU_TITLE + "Cannot register more participants. Max of " + maxParticipants + " participants has already been reached.");
      }
      else {
         //Retrieving and validating name
         while (!moveOn) {
            name = JOptionPane.showInputDialog(MENU_TITLE + "Enter the name of the participant");
         
            if (name.equals("")) {
               JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Name cannot be left blank.");
            }
            else {
               moveOn = true;
            }
         }
      
         moveOn = false;
      
         //Retrieving and validating age
         while (!moveOn) {
            try {
               age = Integer.parseInt(JOptionPane.showInputDialog(MENU_TITLE + "Enter the age of the participant"));
            
               if (age < 0) {
                  JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Age must be a positive number.");
               }
               else if (age < minAge || age > maxAge) {
                  JOptionPane.showMessageDialog(null, MENU_TITLE + "The participant must be between the ages " + minAge + "-" + maxAge + " (inclusive).");
               }
               else {
                  moveOn = true;
               }
            }
            catch (NumberFormatException e) {
               JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
            }
         }
         
         moveOn = false;
      
         //Retrieving and validating sex
         while (!moveOn) {
            userInput = JOptionPane.showInputDialog(MENU_TITLE + "Enter the sex of the participant");
         
            switch(userInput.trim().toLowerCase()){
               case "f":
               case "female": sex = 'f'; moveOn = true; break;
               case "m":
               case "male": sex = 'm'; moveOn = true; break;
               default: JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter male or female."); break;
            }
         }
         
         moveOn = false;
         
         //Retrieving and validating phone number
         while (!moveOn) {
            userInput = JOptionPane.showInputDialog(MENU_TITLE + "Enter the participant's cell phone number\n\nUse this format (y is a number):\nyyy.yyy.yyyy");
            
            if (validatePhone(userInput)) {
               phoneNumber = userInput;
               moveOn = true;
            }
            else {
               JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Phone number is not valid. Please follow the format given.");
            }
         }
         
         moveOn = false;
         
         //Retrieving and validating email address
         while (!moveOn) {
            userInput = JOptionPane.showInputDialog(null, MENU_TITLE + "Enter the participant's email address");
            
            if (validateEmail(userInput)) {
               emailAddress = userInput;
               moveOn = true;
            }
            else {
               JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Email address is not valid.");
            }
         }
         
         moveOn = false;
         
         //Retrieving and validating the organization for sponsored participants only
         while (!moveOn) {
            userInput = JOptionPane.showInputDialog(MENU_TITLE + "Is this a sponsored participant?");
            
            switch (userInput.trim().toLowerCase()){
               case "n":
               case "no": moveOn = true; break;
               case "y":
               case "yes": while (organization.equals("")) {
                              userInput = JOptionPane.showInputDialog(MENU_TITLE + "What is the name of the organization that is\nsponsoring the participant?");
                              
                              if (userInput.equals("")){
                                 JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter the name of the organization.");
                              }
                              else {
                                 organization = userInput;
                              }
                           }
                           moveOn = true;
                           break;
               default: JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter yes or no."); break;
            }
         }
         
         //Retrieving and validating the discount percentage for sponsored participants only
         if (!organization.equals("")) {
            moveOn = false;
            while (!moveOn) {
               userInput = JOptionPane.showInputDialog(MENU_TITLE + "What is the percentage discount this\nindividual recieves?");
               
               //If the user enters a percentage sign just replace with a space so it can later be turned into a number
               if (userInput.indexOf("%") > -1) {
                  userInput.replace("%", " ");
               }
               
               try {
                  percentageDiscount = Integer.parseInt(userInput.trim());
            
                  if (percentageDiscount < 0) {
                     JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Percentage discount must be a positive number.");
                  }
                  else {
                     moveOn = true;
                  }
               }
               catch (NumberFormatException e) {
                  JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
               }
               catch (NullPointerException e) {
                  JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
               }
            }
         }
      
         if (organization.equals("")){
            allParticipants[Participants.getNumOfParticipants()] = new Participants(name, age, sex, phoneNumber, emailAddress);
         }
         else {
            allParticipants[Participants.getNumOfParticipants()] = new SponsoredParticipants(name, age, sex, phoneNumber, emailAddress, organization, percentageDiscount);
         }
      }
   }
   
   /*
   Prompts the user to choose which partcipant they want to enroll in a class. Afterwards, it prompts the user for class and zone information.
   It prompts the user a max of 3 times for classes.
   
   @param allParticipants an array of objects that takes in participant information to enroll participants into classes.
   @param allClasses an array of objects that is used to retrieve class information and validate user input.
   @param maxClasses an integer that is used to limit the max number of classes a participant can enroll into.
   @param allZones an array that is used to retrieve zone information.
   */
   public static void enrollParticipant(Participants[] allParticipants, Classes[] allClasses, int maxClasses, String[] allZones) {
      final String MENU_TITLE = "Enroll:\n\n";
      String report = getParticipantList(allParticipants, MENU_TITLE);
      String userInput = "";
      int chosenParticipant = -1;
      int chosenClass = -1;
      String zone;
      boolean done = false;
      boolean moveOn = false;
      boolean allEnrolled = true;
      String testEnrolled;
      
      for (int i = 0; i < Participants.getNumOfParticipants(); i++) {
         try {
            testEnrolled = allParticipants[i].getEnrolledClasses()[0];
         }
         catch (NullPointerException e) {
            allEnrolled = false;
         }
      }
      
      if (Participants.getNumOfParticipants() == 0) {
         JOptionPane.showMessageDialog(null, MENU_TITLE + "Cannot enroll a participant because there are no participants registered.");
      }
      else if (allEnrolled) {
         JOptionPane.showMessageDialog(null, MENU_TITLE + "Cannot enroll a participant because all registered participants\nhave already been enrolled.");
      }
      else {
         //Validate the participant the user choose from the list of participants
         while (!done) {
            while (!moveOn) {
               try {
                  chosenParticipant = Integer.parseInt(JOptionPane.showInputDialog(report + "Select the participant you would like to enroll in a class"));
                  
                  if (chosenParticipant <= 0) {
                     JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number greater than 0");
                  }
                  else if (chosenParticipant > Participants.getNumOfParticipants()) {
                     JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please choose a number from 1 to " + Participants.getNumOfParticipants() + ".");
                  }
                  else {
                     chosenParticipant -= 1;
                     moveOn = true;
                  }
               }
               catch (NumberFormatException e) {
                  JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
               }
               catch (NullPointerException e) {
                  JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
               }
            }            
                        
            moveOn = false;
            
            boolean validResponse = false;
            //Check to see if the participant is already enrolled in a class
            while (!moveOn){
               //The participant is already enrolled. The user is given a chance to choose another participant
               if (allParticipants[chosenParticipant].getEnrolledClasses() != null) {
                  userInput = JOptionPane.showInputDialog(MENU_TITLE + "This participant is already enrolled in classes.\nWould you like to select another participant?");
               
                  switch (userInput.trim().toLowerCase()) {
                     case "n":
                     case "no": moveOn = true; done = true; break;
                     case "y":
                     case "yes": moveOn = true; break;
                     default: JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter yes or no."); break;
                  }
               }
               //The participant is not enrolled
               else {
                  //Retrieve and validate zone
                  int chosenZone = -1;
                  while (!moveOn){
                     String validZones = "";
               
                     for (int i = 0; i < allZones.length; i++) {
                        validZones += (i+1) + ": " + allZones[i] + "\n";
                     }
               
                     try {
                        chosenZone = Integer.parseInt(JOptionPane.showInputDialog(MENU_TITLE + validZones + "\nWhich zone will the participant's classes be located at?"));
                  
                        if (chosenZone <= 0) {
                           JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number greater than 0");
                        }
                        else if (chosenZone > allZones.length) {
                           JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please choose a number from 1 to " + allZones.length + ".");
                        }
                        else {
                           chosenZone -= 1;
                           moveOn = true;
                        }
                     }
                     catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
                     }
                     catch (NullPointerException e) {
                        JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
                     }
                  }
                  allParticipants[chosenParticipant].setEnrolledZone(allZones[chosenZone]);
                  
                  moveOn = false;
               
                  report = MENU_TITLE;
                  String[] chosenClasses = new String[maxClasses];
                  double totalCost = 0;
                  
                  
                  //Create a list that shows all the classes that are available
                  for (int i = 0; i < allClasses.length; i++){
                     report += (i+1) + ": " + allClasses[i].getName() + "\n";
                  }
                    
                  //Retrieve and validate the class the user choose
                  int count = 0;
                  
                  while (!moveOn && count != maxClasses) {
                     try {
                        chosenClass = Integer.parseInt(JOptionPane.showInputDialog(report + "\nSelect a class to enroll the participant in"));
                  
                        if (chosenClass <= 0){
                           JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please choose a number greater than 0.");
                        }
                        else if (chosenClass > Classes.getNumOfClasses()) {
                           JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please choose a number from 1 to " + Classes.getNumOfClasses() + ".");
                        }
                        //User input is valid
                        else {
                           chosenClass -= 1;
                           //If the participant has been enrolled in classes already make sure the user is not trying to enroll the participant in the same class twice
                           if (count != 0) {
                              boolean duplicate = false;
                              
                              //The user entered a duplicate class show error
                              for (int i = 0; i < count; i++){
                                 if (allClasses[chosenClass].getName().equalsIgnoreCase(chosenClasses[i])) {
                                    JOptionPane.showMessageDialog(null, MENU_TITLE + "Participant has already been enrolled in this class.\nPlease choose another class.");
                                    duplicate = true;
                                 }
                              }
                              
                              if (!duplicate){
                                 chosenClasses[count] = allClasses[chosenClass].getName();
                                 totalCost += allClasses[chosenClass].getCost();
                                 count++;
                                    
                                 //Check to see if the participant has already been enrolled in the max number of classes allowed
                                 if (count != maxClasses) {
                                 //Loop this section until the user states that they either want to enroll the participant in more classes or not.
                                    validResponse = false;
                                    while (!validResponse) {
                                       userInput = JOptionPane.showInputDialog(MENU_TITLE + "Would you like to enroll this participant\nin another class?");
                              
                                       switch (userInput.trim().toLowerCase()) {
                                          case "n":
                                          case "no": validResponse = true; moveOn = true; done = true; break;
                                          case "y":
                                          case "yes": validResponse = true; break;
                                          default: JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter yes or no."); break;
                                       }
                                    }
                                 }
                                 //State that the participant has been enrolled in the max number of classes and the user is going to be sent back to the menu
                                 else {
                                    JOptionPane.showMessageDialog(null, MENU_TITLE + "Participant has been enrolled in a max of " + maxClasses + " classes.\nReturning you to the menu.");
                                    moveOn = true;
                                    done = true;
                                 }
                              }
                           }
                           //Add the class without checking for other classes because the participant hasn't been enrolled in any other classes yet
                           else {
                              chosenClasses[count] = allClasses[chosenClass].getName();
                              totalCost += allClasses[chosenClass].getCost();
                              count++;
                              
                              validResponse = false;
                              while (!validResponse){
                                 userInput = JOptionPane.showInputDialog(MENU_TITLE + "Would you like to enroll this participant\nin another class?");
                              
                                 switch (userInput.trim().toLowerCase()) {
                                    case "n":
                                    case "no": validResponse = true; moveOn = true; done = true; break;
                                    case "y":
                                    case "yes": validResponse = true; break;
                                    default: JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter yes or no."); break;
                                 }
                              }
                           }
                        }
                     }
                     catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
                     }
                     catch (NullPointerException e) {
                        JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
                     }
                  }
                  
                  allParticipants[chosenParticipant].setEnrolledClasses(chosenClasses);
                  allParticipants[chosenParticipant].setBilledPriceRate(totalCost);
               }
            }
         
            moveOn = false;
         }
      }      
   }
   
   /*
   Prompts the user to choose a participant from the list of registered participants. It remove the participant from the
   array of objects and fixes the order of participants in the list.
   
   @param allParticipants an array of objects that is used to retrieve participant information.
   */
   public static void removeEnrolledParticipant(Participants[] allParticipants) {
      final String MENU_TITLE = "Remove Enrolled Participant:\n\n";
      String report = getParticipantList(allParticipants, MENU_TITLE);
      int chosenParticipant = -1;
      boolean done = false;
      
      if (Participants.getNumOfParticipants() == 0) {
         JOptionPane.showMessageDialog(null, MENU_TITLE + "Cannot remove a participant because there are no participants registered.");
      }
      else {
         //Validate the participant the user choose from the list of participants
         while (!done) {
            try {
               chosenParticipant = Integer.parseInt(JOptionPane.showInputDialog(report + "Select the participant you would like to remove:"));
               
               if (chosenParticipant <= 0) {
                  JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number greater than 0");
               }
               else if (chosenParticipant > Participants.getNumOfParticipants()) {
                  JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please choose a number from 1 to " + Participants.getNumOfParticipants() + ".");
               }
               else {
                  //Handle removing the participant from the registered list
                  chosenParticipant -= 1;
                  allParticipants[chosenParticipant].removeParticipant();
                  fixParticipantOrder(allParticipants);
                  done = true;
               }
            }
            catch (NumberFormatException e) {
               JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
            }
         }            
      }
   }
   
   /*
   Prompts the user to choose a participant from the list of registered participants. It prints all the information
   related to the chosen participant.
   
   @param allParticipants an array of objects that is used to retrieve participant information.
   */
   public static void printParticipantRecord(Participants[] allParticipants) {
      final String MENU_TITLE = "Print Participant Record:\n\n";
      String report = getParticipantList(allParticipants, MENU_TITLE);
      int chosenParticipant = -1;
      boolean done = false;
      
      if (Participants.getNumOfParticipants() == 0) {
         JOptionPane.showMessageDialog(null, MENU_TITLE + "Cannot print a participant record because there are no participants registered.");
      }
      else {
         //Validate the participant the user choose from the list of participants
         while (!done) {
            try {
               chosenParticipant = Integer.parseInt(JOptionPane.showInputDialog(report + "Select the participant you would like view information on:"));
                  
               if (chosenParticipant <= 0) {
                  JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number greater than 0");
               }
               else if (chosenParticipant > Participants.getNumOfParticipants()) {
                  JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please choose a number from 1 to " + Participants.getNumOfParticipants() + ".");
               }
               else {
                  //Handling printing the participant record
                  chosenParticipant -= 1;
                  JOptionPane.showMessageDialog(null, "Participant Information:\n\n" + allParticipants[chosenParticipant].toString());
                  done = true;
               }
            }
            catch (NumberFormatException e) {
               JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, MENU_TITLE + "Error. Please enter a number.");
            }
         }            
      }

   }
   
   /*
   Creates a string that lists all the names of all the participants in the list of the registered.
   
   @param allParticipants an array of objects that is used to retrieve participant information.
   @param title a string that displays the name of the menu option the user choose to make sure the user knows what the information is being used for.
   
   @return a string with a lists all the names of the participants that have been registered.
   */
   public static String getParticipantList(Participants[] allParticipants, String title) {
      String report = title;
      
      for (int i = 0; i < Participants.getNumOfParticipants(); i++) {
         report += "Participant #" + (i+1) + ":\n" + allParticipants[i].getName() + "\n\n";
      }
      
      return report;
   }
   
   /*
   Fixes the participant order when the registered participant list has gaps from removing a participant from the list.
   
   @param allParticipants an array of objects that is used to retrieve and update participant information.
   */
   public static void fixParticipantOrder(Participants[] allParticipants){
      //Gets the participant after an empty spot and moves it into the empty spot before it. Runs through until the list is fixed with no empty spots between recorded participants
      for (int i = 0; i < (Participants.getNumOfParticipants() + 1); i++) {
         if (allParticipants[i].getName().equalsIgnoreCase("")) {
            if (i != Participants.getNumOfParticipants()){
               Participants participantInfo = allParticipants[i + 1];
               Participants emptyParticipant = allParticipants[i];
               allParticipants[i] = participantInfo;
               allParticipants[i + 1] = emptyParticipant;
            }
         }
      }
   }
   
   /*
   Determines if the string provided by the user in a different method is a valid phone number or not.
   
   @param phone a string that was provided by the user and is going to be validated by this method.
   
   @return a boolean that states whether or not the string that was provided is a valid phone number.
   */
   public static boolean validatePhone(String phone) {
      final char SEPARATOR = '.';
      boolean valid = false;
      int testSection;
      
      if (phone.length() == 12) {
         //Check to see if the separators are in the correct positions
         if (phone.indexOf(SEPARATOR) == 3 && phone.indexOf(SEPARATOR, 4) == 7){
            //Test each section to see if they are only numbers. If they are not numbers then it is not a valid phone number
            try {
               testSection = Integer.parseInt(phone.substring(0,3));
               testSection = Integer.parseInt(phone.substring(4,7));
               testSection = Integer.parseInt(phone.substring(8,12));
               
               valid = true;
            }
            catch(NumberFormatException e){
               valid = false;
            }
         }
      }
      
      return valid;
   }
   
   /*
   Determines if the string provided by the user in a different method is a valid email address or not.
   
   @param email a string that was provided by the user and is going to be validated by this method.
   
   @return a boolean that states whether or not the string that was provided is a valid email address.
   */
   public static boolean validateEmail(String email) {
      boolean valid = false;
      
      //Checking to see if '@' and '.' are in the email at the same time making sure they are not the first character
      if (email.indexOf('@') > 0 && email.indexOf('.') > 0) {
         int count = 0;
      
         //Make sure there is only one '@' in the email
         for (int i = 0; i < email.length(); i++) {
            if (email.charAt(i) == '@') {
               count += 1;
            }
         }
         
         if (count == 1) {
            int lastDotOccurrence = -1;
            
            for (int i = 0; i < email.length(); i++) {
               if (email.charAt(i) == '.') {
                  lastDotOccurrence = i;
               }
            }
                        
            //Checking to see if the last occurrence of '.' is after the '@'
            if (lastDotOccurrence > email.indexOf('@')) {
               //Checking to see if there are at least two characters after the last '.' occurrence
               if ((email.length() - 1) - lastDotOccurrence >= 2) {
                  //Checking to see if first character is a letter or a digit
                  if (Character.isLetter(email.charAt(0)) == true || Character.isDigit(email.charAt(0)) == true) {
                     //Making sure the email is limited to letters, digits, '_', '@', and '.'
                     valid = true;
                     for (int i = 0; i < email.length(); i++){
                        if (Character.isLetter(email.charAt(i)) == false && Character.isDigit(email.charAt(i)) == false) {
                           if (email.charAt(i) != '_' && email.charAt(i) != '@' && email.charAt(i) != '.') {
                              valid = false;
                           }
                        }
                     }
                  }
               }
            }
         }
      }
      
      return valid;
   }
}