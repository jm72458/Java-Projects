/*
Jessica Montoya
11/16/20
IT 206-202
Assignment 10
In this program, the user will input information for one or many customers and virtual machines for GMU Cloud. The information the user will input for a virtual machine
will vary depending on its type. The types include web servers, file servers, and bitcoin miners. For web server, the user will input information such as the amount of
additional memory the web server use. For file server, the user will input information such as the storage type, the storage media type, and the amount of additional storage
the file server will use. For bitcoin miner, the user will input information such as number of GPUs and the brand of the GPUs the bitcoin miner VM will use. The program uses
this information to create customer statistics and display the information in different ways. This program is designed to be flexible in terms of the max number of customers,
the charges for specific features, the starting amount of different resources. This flexibility was added in case changes needed to be done to the program in the future.
*/

public class WebServers extends VMs {
   private int additionalMemory;
   public final static int MAX_ADDITIONAL_MEMORY = 120;
   public final static double ADDITIONAL_MEMORY_RATE = 10;
   public final static int ADDITIONAL_MEMORY_INCREMENTS = 8;
   public static int numWebServers = 0;
   
   /*
   Constructs a WebServers object with a specified amount of additional memory for a web server virtual machine.
   
   @param newMemory an int that adds additional memory to the web server virtual machine.
   */
   public WebServers(int newMemory) {
      super(newMemory);
      this.additionalMemory = newMemory;
   }
   
   /*
   Constructs a WebServers object by making a copy of another WebServers object.
   
   @param customerVM a WebServers object that will be used to obtain information for the WebServer object copy.
   */
   public WebServers(WebServers customerVM) {
      super(customerVM.getAdditionalMemory());
      this.additionalMemory = customerVM.getAdditionalMemory();
      numWebServers++;
   }
   
   /*
   When called it returns the number of web server virtual machines objects that have been created.
   
   @return an int that represents the number of web server virtual machines objects that have been created.
   */
   public static int getNumWebServers() {
      return numWebServers;
   }
   
   /*
   When called it returns the amount of additional memory used for that specific web server virtual machine.
   
   @return an int that represents the amount of additional memory used for that specific web server virtual machine.
   */
   private int getAdditionalMemory() {
      return this.additionalMemory;
   }
   
   /*
   When called it returns the monthly cost for that specific web server virtual machine.
   
   @return a double that represents the monthly cost for that specific web server virtual machine.
   */
   public double getMonthlyCost() {
      return (super.FLAT_MONTHLY_RATE + ((this.additionalMemory / ADDITIONAL_MEMORY_INCREMENTS) * ADDITIONAL_MEMORY_RATE));
   }
   
   /*
   When called it returns the information related to that specific web server virtual machine.
   
   @return a string that represents the information related to that specific web server virtual machine.
   */  
   public String toString() {
      String report = "VM Type: Web Server" + 
                      "\nMemory: " + super.getMemory() +" GB";
      
      if (super.getStorage() >= 1000) {
         report += "\nSSD Storage: " + (super.getStorage() / 1000.0) + " TB";
      }
      else {
         report += "\nSSD Storage: " + super.getStorage() + " GB";
      }
      
      report += "\nMonthly Cost: $" + String.format("%.2f", this.getMonthlyCost());
   
      return report;
   }
}