/*
Jessica Montoya
11/16/20
IT 206-202
Assignment 10
In this program, the user will input information for one or many customers and virtual machines for GMU Cloud. The information the user will input for a virtual machine
will vary depending on its type. The types include web servers, file servers, and bitcoin miners. For web server, the user will input information such as the amount of
additional memory the web server use. For file server, the user will input information such as the storage type, the storage media type, and the amount of additional storage
the file server will use. For bitcoin miner, the user will input information such as number of GPUs and the brand of the GPUs the bitcoin miner VM will use. The program uses
this information to create customer statistics and display the information in different ways. This program is designed to be flexible in terms of the max number of customers,
the charges for specific features, the starting amount of different resources. This flexibility was added in case changes needed to be done to the program in the future.
*/

public class FileServers extends VMs {
   private String storageType;
   private String storageMediaType;
   private double magneticStorageInTB;
   public static final int MAX_STORAGE_IN_TB = 1024;
   public static final int SSD_MONTHLY_TB_COST = 5;
   public static final int MAGNETIC_MONTHLY_TB_COST = 2;
   public static int numFileServers = 0;
   
   /*
   Constructs a FileServers object with a specified storage type, storage media type, and additional storage amount for a file server virtual machine.
   
   @param newStorageType the string that will be given to a file server virtual machine for its storage type.
   @param newStorageMediaType the string that will be given to a file server virtual machine for its storage media type.
   @param newStorageAmount a double that adds additional storage to the file server virtual machine.
   */
   public FileServers(String newStorageType, String newStorageMediaType, double newStorageAmount) {
      super();
      this.storageType = newStorageType;
      this.storageMediaType = newStorageMediaType;
      
      if (newStorageMediaType.equals("Magnetic Storage")) {
         this.magneticStorageInTB = newStorageAmount;
      }
      else {
         this.magneticStorageInTB = 0;
         super.setStorage(super.getStorage() + (int)(newStorageAmount * 1000));
      }
   }
   
   /*
   Constructs a FileServers object by making a copy of another FileServers object.
   
   @param customerVM a FileServers object that will be used to obtain information for the FileServer object copy.
   */
   public FileServers(FileServers customerVM) {
      super();
      this.storageType = customerVM.getStorageType();
      this.storageMediaType = customerVM.getStorageMediaType();
      this.magneticStorageInTB = customerVM.getMagneticStorage();
      super.setStorage(customerVM.getStorage());
      numFileServers++;
   }
   
   /*
   When called it returns the storage type for that specific file server virtual machine.
   
   @return a String that represents the storage type for that specific file server virtual machine.
   */
   public String getStorageType() {
      return this.storageType;
   }
   
   /*
   When called it returns the storage media type for that specific file server virtual machine.
   
   @return a String that represents the storage media type for that specific file server virtual machine.
   */
   public String getStorageMediaType() {
      return this.storageMediaType;
   }
   
   /*
   When called it returns the amount of magnetic storage used for that specific file server virtual machine.
   
   @return a double that represents the amount of magnetic storage used for that specific file server virtual machine.
   */
   public double getMagneticStorage() {
      return this.magneticStorageInTB;
   }
   
   /*
   When called it returns the number of file server virtual machines objects that have been created.
   
   @return an int that represents the number of file server virtual machines objects that have been created.
   */
   public static int getNumFileServers() {
      return numFileServers;
   }
   
   /*
   When called it returns the monthly cost for that specific file server virtual machine.
   
   @return a double that represents the monthly cost for that specific file server virtual machine.
   */
   public double getMonthlyCost() {
      double cost = 0;
      
      if (this.storageMediaType.equals("SSD")) {
         cost = super.FLAT_MONTHLY_RATE + (((super.getStorage() - super.STARTING_SSD_STORAGE) / 1000) * SSD_MONTHLY_TB_COST);
      }
      else {
         cost = super.FLAT_MONTHLY_RATE + (this.magneticStorageInTB * MAGNETIC_MONTHLY_TB_COST);
      }
      
      return cost;
   }
   
   /*
   When called it returns the information related to that specific file server virtual machine.
   
   @return a string that represents the information related to that specific file server virtual machine.
   */  
   public String toString() {
      String report = "";
      
      if (storageMediaType.equals("Magnetic Storage")) {
         report = "VM Type: File Server" + 
                  "\n" + this.storageType + " Storage" +
                  "\nMemory: " + super.getMemory() +" GB" + 
                  "\nSSD Storage: " + super.getStorage() + " GB" +
                  "\nMagnetic Storage: " + this.magneticStorageInTB + " TB" +
                  "\nMonthly Cost: $" + String.format("%.2f", this.getMonthlyCost());
      }
      else {
         report = "VM Type: File Server" + 
                  "\n" + this.storageType + " Storage" +
                  "\nMemory: " + super.getMemory() +" GB";
                  
         if (super.getStorage() >= 1000) {
            report += "\nSSD Storage: " + (super.getStorage() / 1000.0) + " TB";
         }
         else {
            report += "\nSSD Storage: " + super.getStorage() + " GB";
         }
         
         report += "\nMonthly Cost: $" + String.format("%.2f", this.getMonthlyCost());
      }
      
      return report;
   }
}