/*
Jessica Montoya
11/16/20
IT 206-202
Assignment 10
In this program, the user will input information for one or many customers and virtual machines for GMU Cloud. The information the user will input for a virtual machine
will vary depending on its type. The types include web servers, file servers, and bitcoin miners. For web server, the user will input information such as the amount of
additional memory the web server use. For file server, the user will input information such as the storage type, the storage media type, and the amount of additional storage
the file server will use. For bitcoin miner, the user will input information such as number of GPUs and the brand of the GPUs the bitcoin miner VM will use. The program uses
this information to create customer statistics and display the information in different ways. This program is designed to be flexible in terms of the max number of customers,
the charges for specific features, the starting amount of different resources. This flexibility was added in case changes needed to be done to the program in the future.
*/

public abstract class VMs {
   private int memoryInGB;
   private double ssdStorageInGB;
   public static final int STARTING_MEMORY = 8;
   public static final int STARTING_SSD_STORAGE = 20;
   public static final double FLAT_MONTHLY_RATE = 20;
   
   /*
   Constructs a VM with the default amount of memory and storage for a virtual machine.
   */
   public VMs() {
      this.memoryInGB = STARTING_MEMORY;
      this.ssdStorageInGB = STARTING_SSD_STORAGE;
   }
   
   /*
   Constructs a VM with a specified amount of memory and the default amount of storage for a virtual machine.
   
   @param newMemory an int that adds additional memory to the virtual machine.
   */
   public VMs(int newMemory) {
      this.memoryInGB = STARTING_MEMORY + newMemory;
      this.ssdStorageInGB = STARTING_SSD_STORAGE;
   }
   
   /*
   When called it returns the amount of memory used for that specific virtual machine.
   
   @return an int that represents the amount of memory used for that specific virtual machine.
   */
   public int getMemory() {
      return this.memoryInGB;
   }
   
   /*
   When called it returns the amount of storage used for that specific virtual machine.
   
   @return a double that represents the amount of storage used for that specific virtual machine.
   */
   public double getStorage() {
      return this.ssdStorageInGB;
   }
   
   /*
   When called it changes the storage used for a specific virtual machine.
   
   @param newStorage a double that will change the amount of storage used by a specific virtual machine.
   */
   public void setStorage(double newStorage) {
      this.ssdStorageInGB = newStorage;
   }
   
   /*
   When called it returns the monthly cost for that specific virtual machine.
   
   @return a double that represents the monthly cost for that specific virtual machine.
   */
   public abstract double getMonthlyCost();
    
   /*
   When called it returns the information related to that specific virtual machine.
   
   @return a string that represents the information related to that specific virtual machine.
   */  
   public abstract String toString();
}