/*
Jessica Montoya
11/16/20
IT 206-202
Assignment 10
In this program, the user will input information for one or many customers and virtual machines for GMU Cloud. The information the user will input for a virtual machine
will vary depending on its type. The types include web servers, file servers, and bitcoin miners. For web server, the user will input information such as the amount of
additional memory the web server use. For file server, the user will input information such as the storage type, the storage media type, and the amount of additional storage
the file server will use. For bitcoin miner, the user will input information such as number of GPUs and the brand of the GPUs the bitcoin miner VM will use. The program uses
this information to create customer statistics and display the information in different ways. This program is designed to be flexible in terms of the max number of customers,
the charges for specific features, the starting amount of different resources. This flexibility was added in case changes needed to be done to the program in the future.
*/

public class Customers {
   private String id;
   private String name;
   private String phoneNumber;
   private String emailAddress;
   private boolean corporateDiscount;
   private VMs customerVM;
   public static int numOfCustomers = 0;
   public static final int DISCOUNT_AMOUNT = 20;
   
   /*
   Constructs a customer with a specified name, phone number, email address, and corporate discount.
   
   @param newName the string that will be given to a customer for its name
   @param newPhoneNumber the string that will be given to a customer for its phone number
   @param newEmailAddress the string that will be given to a customer for its email address
   @param newCorporateDiscount the boolean that will be given to a customer for it corporate discount status
   */
   public Customers(String newName, String newPhoneNumber, String newEmailAddress, boolean newCorporateDiscount) {
      this.id = "usr" + (1000 + numOfCustomers);
      this.name = newName;
      this.phoneNumber = newPhoneNumber;
      this.emailAddress = newEmailAddress;
      this.corporateDiscount = newCorporateDiscount;
      numOfCustomers++;
   }
   
   /*
   Constructs a customer with a specified name, phone number, email address, corporate discount, and web server virtual machine.
   
   @param newName the string that will be given to a customer for its name
   @param newPhoneNumber the string that will be given to a customer for its phone number
   @param newEmailAddress the string that will be given to a customer for its email address
   @param newCorporateDiscount the boolean that will be given to a customer for it corporate discount status
   @param customerVM the WebServers object that will be given to a customer for its virtual machine
   */
   public Customers(String newName, String newPhoneNumber, String newEmailAddress, boolean newCorporateDiscount, WebServers customerVM) {
      this(newName, newPhoneNumber, newEmailAddress, newCorporateDiscount);
      this.customerVM = new WebServers(customerVM);
   }
   
   /*
   Constructs a customer with a specified name, phone number, email address, corporate discount, and file server virtual machine.
   
   @param newName the string that will be given to a customer for its name
   @param newPhoneNumber the string that will be given to a customer for its phone number
   @param newEmailAddress the string that will be given to a customer for its email address
   @param newCorporateDiscount the boolean that will be given to a customer for it corporate discount status
   @param customerVM the FileServers object that will be given to a customer for its virtual machine
   */
   public Customers(String newName, String newPhoneNumber, String newEmailAddress, boolean newCorporateDiscount, FileServers customerVM) {
      this(newName, newPhoneNumber, newEmailAddress, newCorporateDiscount);
      this.customerVM = new FileServers(customerVM);
   }
   
   /*
   Constructs a customer with a specified name, phone number, email address, corporate discount, and bitcoin miner virtual machine.
   
   @param newName the string that will be given to a customer for its name
   @param newPhoneNumber the string that will be given to a customer for its phone number
   @param newEmailAddress the string that will be given to a customer for its email address
   @param newCorporateDiscount the boolean that will be given to a customer for it corporate discount status
   @param customerVM the BitcoinMiners object that will be given to a customer for its virtual machine
   */
   public Customers(String newName, String newPhoneNumber, String newEmailAddress, boolean newCorporateDiscount, BitcoinMiners customerVM) {
      this(newName, newPhoneNumber, newEmailAddress, newCorporateDiscount);
      this.customerVM = new BitcoinMiners(customerVM);
   }
   
   /*
   When called it returns the total number of customers that have been entered into the program.
   
   @return an int that represents the total number of customers that have been entered into the program.
   */
   public static int getNumOfCustomers() {
      return numOfCustomers;
   }
   
   /*
   When called it returns the customer ID for that specific customer.
   
   @return a string that represents the customer ID for that specific customer.
   */
   public String getID() {
      return this.id;
   }
   
   /*
   When called it returns the name for that specific customer.
   
   @return a string that represents the name for that specific customer.
   */
   public String getName() {
      return this.name;
   }
   
   /*
   When called it returns the monthly fee for that specific customer.
   
   @return a double that represents the monthly fee for that specific customer.
   */
   public double getMonthlyFee() {
      double cost = 0.0;
      
      if (this.corporateDiscount) {
         cost = this.customerVM.getMonthlyCost() - (this.customerVM.getMonthlyCost() * (DISCOUNT_AMOUNT/100.0));
      }
      else {
         cost = this.customerVM.getMonthlyCost();
      }
      
      return cost;
   }
   
   /*
   When called it returns the amount of memory used for the customer's VM for that specific customer.
   
   @return an int that represents the amount of memory used for the customer's VM for that specific customer.
   */
   public int getVMMemory() {
      return this.customerVM.getMemory();
   }
   
   /*
   When called it returns the amount of disk space used for the customer's VM for that specific customer.
   
   @return a double that represents the amount of disk space used for the customer's VM for that specific customer.
   */
   public double getVMDiskSpace() {
      double storage = this.customerVM.getStorage();
      
      //Add magnetic storage to the total storage count
      if (this.customerVM instanceof FileServers) {
         storage += (((FileServers) this.customerVM).getMagneticStorage() * 1000);
      }
      
      return storage;
   }
   
   /*
   When called it returns the number of GPUs used for the customer's VM for that specific customer.
   
   @return an int that represents the number of GPUs used for the customer's VM for that specific customer.
   */
   public int getNumVMGPUs() {
      int numGPUs = 0;
      
      if (this.customerVM instanceof BitcoinMiners && this.customerVM != null) {
         numGPUs = ((BitcoinMiners)this.customerVM).getNumGPUs();
      }
      
      return numGPUs;
   }
   
   /*
   When called it returns the ID, name, phone number, email address, corporate discount status, VM information, and monthly cost(s) for that specific customer.
   
   @return a string that represents the ID, name, phone number, email address, corporate discount status, VM information, and monthly cost(s) for that specific customer.
   */
   public String toString() {
      String report = "";
   
      if (this.corporateDiscount) {
         report = "id: " + this.id +
                  "\nName: " + this.name +
                  "\nPhone Number: " + this.phoneNumber +
                  "\nEmail Address: " + this.emailAddress + 
                  "\nCorporate Discount: " + DISCOUNT_AMOUNT + "%" +
                  "\n\n" + this.customerVM.toString() +
                  "\n\nMonthly Cost With Discount: $" + String.format("%.2f", (this.customerVM.getMonthlyCost() - (this.customerVM.getMonthlyCost() * (DISCOUNT_AMOUNT/100.0))));
      }
      else {
         report = "id: " + this.id +
                  "\nName: " + this.name +
                  "\nPhone Number: " + this.phoneNumber +
                  "\nEmail Address: " + this.emailAddress + 
                  "\n\n" + this.customerVM.toString();
      }
   
      return report;
   }
}