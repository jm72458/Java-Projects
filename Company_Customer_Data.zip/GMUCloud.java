/*
Jessica Montoya
11/16/20
IT 206-202
Assignment 10
In this program, the user will input information for one or many customers and virtual machines for GMU Cloud. The information the user will input for a virtual machine
will vary depending on its type. The types include web servers, file servers, and bitcoin miners. For web server, the user will input information such as the amount of
additional memory the web server use. For file server, the user will input information such as the storage type, the storage media type, and the amount of additional storage
the file server will use. For bitcoin miner, the user will input information such as number of GPUs and the brand of the GPUs the bitcoin miner VM will use. The program uses
this information to create customer statistics and display the information in different ways. This program is designed to be flexible in terms of the max number of customers,
the charges for specific features, the starting amount of different resources. This flexibility was added in case changes needed to be done to the program in the future.
*/

import javax.swing.JOptionPane;
import java.io.*;
import javax.swing.JFileChooser;

public class GMUCloud {
   public static void main (String[] args) {
      final int MAX_CUSTOMERS = 1000;
      
      Customers[] allCustomers = new Customers[MAX_CUSTOMERS];
      
      getCustomerInfo(allCustomers);
      printCustomerStatisticsReport(allCustomers);
      createPrintableRoster(allCustomers);
   }
   
   /*
   Continuously prompts the user for a customer information to create a customer object. It also displays individual customer information
   after the customer object has been created. The prompts stop when the user reaches the max limit of customers or the user ends the prompts.
   
   @param allCustomers an array that takes in customer information and the customer's associated virtual machine.
   */
   public static void getCustomerInfo(Customers[] allCustomers) {
      boolean done = false;
      boolean moveOn = false;
      String userInput;
      String customerName = "";
      String customerPhone = "";
      String customerEmail = "";
      boolean corporateDiscount = false;
      boolean valid;
      final String[] VM_CUSTOMIZATIONS = {"Web server", "File server", "Bitcoin miner"};
      
      //Retrieve and validate the customer's name
      while (!done) {
         moveOn = false;
         
         while (!moveOn) {
            userInput = JOptionPane.showInputDialog("Enter the customer's name:");
         
            //Validate the name
            if (userInput.trim().equals("")) {
               JOptionPane.showMessageDialog(null, "Error. Please enter a name for the customer.");
            }
            else {
               customerName = userInput.trim().substring(0,1).toUpperCase() + userInput.trim().substring(1, userInput.length()).toLowerCase();
      
               //If the user entered multiple names for the customer then captialize each name
               if (customerName.indexOf(' ') > -1) {
                  String newName = "";
                  int lastIndex = -2;
         
                  for (int i = 0; i < (customerName.length() - 1); i++) {
                     if (customerName.charAt(i) == ' '){
                        newName += customerName.substring(i+1, i+2).toUpperCase() + customerName.substring(lastIndex + 2, i + 1);
                        lastIndex = i;
                     }
                  }
         
                  if (lastIndex + 2 < customerName.length()) {
                     newName += customerName.substring(lastIndex + 2, customerName.length());
                  }
         
                  customerName = newName;
               }
                           
               moveOn = true;
            }
         }
         
         moveOn = false;
         
         //Retrieve and validate the customer's phone number
         while (!moveOn) {
            userInput = JOptionPane.showInputDialog("Enter the customer's phone number:\n\nUse this format (x is a number):\n(xxx) xxx-xxxx");
            
            //Validate the phone number
            if (userInput.trim().length() != 14) {
               JOptionPane.showMessageDialog(null, "Error. Please use the format provided.");
            }
            else {
               if (userInput.trim().indexOf(' ') < 0) {
                  //Check if it has a space
                  JOptionPane.showMessageDialog(null, "Error. Please use the format provided.");
               }
               else {
                  //Check if the parentheses are there and in the correct places
                  if (userInput.trim().indexOf('(') != 0 && userInput.trim().indexOf(')') != 4) {
                     JOptionPane.showMessageDialog(null, "Error. Please use the format provided.");
                  }
                  else {
                     //Check if the - is there and in the correct place
                     if (userInput.trim().indexOf('-') != 9) {
                        JOptionPane.showMessageDialog(null, "Error. Please use the format provided.");
                     }
                     else {
                        //Check to see if all the numbers in the phone number are numbers
                        String testDigits = userInput.trim().substring(1,4) + userInput.trim().substring(6,9) + userInput.trim().substring(10,14);
                        valid = true;
                     
                        for (int i = 0; i < testDigits.length(); i++) {
                           if (!Character.isDigit(testDigits.charAt(i))) {
                              valid = false;
                           }
                        }
                     
                        //The phone number is valid move on to the next prompt
                        if (valid) {
                           customerPhone = userInput.trim();
                           moveOn = true;
                        }
                        else {
                           JOptionPane.showMessageDialog(null, "Error. Please use the format provided."); 
                        }
                     }
                  }
               }
            }
         }
         
         moveOn = false;
         
         //Retrieve and validate the customer's email address
         while (!moveOn) {
            userInput = JOptionPane.showInputDialog("Enter the customer's email address.");
            
            //Validate email address
            if (userInput.trim().indexOf('@') < 0) {
               //If the email does not have @ in it
               JOptionPane.showMessageDialog(null, "Error. The email must contain '@'");
            }
            else {
               //Check if the email has a . in it
               if (userInput.trim().indexOf('.') < 0) {
                  JOptionPane.showMessageDialog(null, "Error. The email must contain '.'");
               }
               else {
                  //Check if there is only one @ in the email
                  int atLocation = userInput.trim().indexOf('@');
               
                  if (userInput.trim().indexOf('@', atLocation + 1) > -1) {
                     //There is more than one @
                     JOptionPane.showMessageDialog(null, "Error. The email can only contain one '@'");
                  }
                  else {
                     //Check if there is only one . in the email
                     int periodLocation = userInput.trim().indexOf('.');
                  
                     if (userInput.trim().indexOf('.', periodLocation + 1) > -1) {
                        JOptionPane.showMessageDialog(null, "Error. The email can only contain one '.'");
                     }
                     else {
                        //Check if the @ is before the .
                        if (userInput.trim().indexOf('@') > userInput.trim().indexOf('.')) {
                           JOptionPane.showMessageDialog(null, "Error. The '@' must come before the '.'");
                        }
                        else {
                           //Check if there is at least one letter or digit before @
                           if (!Character.isLetter(userInput.trim().charAt(0)) && !Character.isDigit(userInput.trim().charAt(0))) {
                              JOptionPane.showMessageDialog(null, "Error. Please enter letters or numbers before '@'");
                           }
                           else {
                              //Check if there are letters or digits between @ and .                           
                              if (periodLocation - atLocation < 2) {
                                 JOptionPane.showMessageDialog(null, "Error. Please enter letters or numbers between '@' and '.'");
                              }
                              else {
                                 valid = true;
                              
                                 //Check if the characters between @ and . are either letters or digits
                                 for (int i = atLocation + 1; i < periodLocation; i++) {
                                    if (!Character.isLetter(userInput.trim().charAt(i)) && !Character.isDigit(userInput.trim().charAt(i))) {
                                       valid = false;
                                    }
                                 }
                                 
                                 if (!valid) {
                                    JOptionPane.showMessageDialog(null, "Error. Please enter letters or numbers between '@' and '.'");
                                 }
                                 else {
                                    valid = true;
                                    
                                    //Check if there are letters or digits after the .
                                    for (int i = periodLocation + 1; i < userInput.length(); i++) {
                                       if (!Character.isLetter(userInput.trim().charAt(i)) && !Character.isDigit(userInput.trim().charAt(i))) {
                                       valid = false;
                                       }
                                    }
                                    
                                    if (!valid) {
                                       JOptionPane.showMessageDialog(null, "Error. Please enter letters or numbers after the '.'");
                                    }
                                    else {
                                       //The email is valid move on to the next prompt
                                       customerEmail = userInput.trim();
                                       moveOn = true;
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
         
         moveOn = false;
         
         //Figure out if the customer has a corporate discount
         while (!moveOn) {
            userInput = JOptionPane.showInputDialog("Does the customer have a corporate discount.");
            
            switch(userInput.trim().toLowerCase()) {
               case "n":
               case "no": corporateDiscount = false; moveOn = true; break;
               case "y":
               case "yes": corporateDiscount = true; moveOn = true; break;
               default: JOptionPane.showMessageDialog(null, "Error. Please enter yes or no."); break;
            }

         }
         
         moveOn = false;
         Customers newCustomer = null;
         String report = "";
         for (int i = 0; i < VM_CUSTOMIZATIONS.length; i++) {
            report += (i + 1) + ": " + VM_CUSTOMIZATIONS[i] + "\n";
         }
         
         //Get information for the VM customization the user is getting
         while (!moveOn) {
            userInput = JOptionPane.showInputDialog("Which VM customization fits the customer's needs?\n\nChoose from the following:\n" + report);
            
            switch(userInput.trim()) {
               case "1": newCustomer = new Customers(customerName, customerPhone, customerEmail, corporateDiscount, getWebServerVMInfo());
                         moveOn = true; break;
               case "2": newCustomer = new Customers(customerName, customerPhone, customerEmail, corporateDiscount, getFileServerVMInfo());
                         moveOn = true; break;
               case "3": newCustomer = new Customers(customerName, customerPhone, customerEmail, corporateDiscount, getBitcoinMinerVMInfo());
                         moveOn = true; break;
               default: JOptionPane.showMessageDialog(null, "Error. Please enter a number from 1 to " + VM_CUSTOMIZATIONS.length); break;
            }
         }
         allCustomers[Customers.getNumOfCustomers() - 1] = newCustomer;
         JOptionPane.showMessageDialog(null, newCustomer.toString());
         
         //Ask to enter another customer when the maximum number of customers has not been reached
         if (Customers.getNumOfCustomers() != allCustomers.length) {
            moveOn = false;
              
            //Ask the user if they want to enter another customer to either loop again or break the loop
            while (!moveOn) {
               userInput = JOptionPane.showInputDialog("Would you like to enter information for another customer?");
            
               switch(userInput.trim()) {
                  case "n":
                  case "no": moveOn = true; done = true; break;
                  case "y":
                  case "yes": moveOn = true; break;
                  default: JOptionPane.showMessageDialog(null, "Error. Please enter yes or no."); break;
               }
            }
         }
         else {
            JOptionPane.showMessageDialog(null, "The maximum number of customers with information has been entered. No more customer\ninformation can be added. A summary report on customer statistics will be displayed.");
            done = true;
         }
      }      
   }
   
   /*
   Prompts the user for information on a web server virtual machine. Prompts for information such as the amount of
   additional memory that will be added to the VM. With this information, a WebServers object will be instantiated.
   
   @return a WebServers object that represents a customer's web server virtual machine.
   */
   public static WebServers getWebServerVMInfo() {
      WebServers customerVM = null;
      String userInput = "";
      int additionalMemory = 0;
      boolean done = false;
      
      while (!done) {
         userInput = JOptionPane.showInputDialog("How much additional memory in GB will be added?");
         
         //Validate additional memory
         try {
            additionalMemory = Integer.parseInt(userInput.trim());
            
            if (additionalMemory <= 0) {
               JOptionPane.showMessageDialog(null, "Please enter a number greater than 0.");
            }
            else if (additionalMemory > WebServers.MAX_ADDITIONAL_MEMORY){
               JOptionPane.showMessageDialog(null, "Please enter a number less than or equal to " + WebServers.MAX_ADDITIONAL_MEMORY + ".");
            }
            else {
               done = true;
            }
         }
         catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a number.");
         }
         catch(NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error. Please enter a number.");
         }
      }
      
      customerVM = new WebServers(additionalMemory);
      return customerVM;
   }
   
   /*
   Prompts the user for information on a file server virtual machine. Prompts for information such as the storage
   type, the storage media type, and additional storage that will be added to the VM. With this information, a 
   FileServers object will be instantiated.
   
   @return a FileServers object that represents a customer's file server virtual machine.
   */
   public static FileServers getFileServerVMInfo() {
      FileServers customerVM = null;
      String storageType = "";
      String storageMediaType = "";
      double storageAmount = 0;
      String userInput = "";
      boolean done = false;
      
      //Retrieve and validate storage type
      while (!done) {
         userInput = JOptionPane.showInputDialog("Will this file server use block storage or object storage?");
         
         switch (userInput.trim().toLowerCase()) {
            case "block":
            case "block storage": storageType = "Block"; done = true; break;
            case "object":
            case "object storage": storageType = "Object"; done = true; break;
            default: JOptionPane.showMessageDialog(null, "Error. Please enter block storage or object storage.");
         }
      }
      
      done = false;
      
      //Retrieve and validate storage media type
      while (!done) {
         userInput = JOptionPane.showInputDialog("Will this file server use SSD or magnetic storage?");
         
         switch (userInput.trim().toLowerCase()) {
            case "ssd": storageMediaType = "SSD"; done = true; break;
            case "magnetic":
            case "magnetic storage": storageMediaType = "Magnetic Storage"; done = true; break;
            default: JOptionPane.showMessageDialog(null, "Error. Please enter SSD or magnetic storage.");
         }
      }
      
      done = false;
      
      //Retrieve and validate amount of storage
      while (!done) {
         userInput = JOptionPane.showInputDialog("How much storage in TB will be needed?\n(" + VMs.STARTING_SSD_STORAGE + " GB of SSD already included)");
         
         try {
            storageAmount = Integer.parseInt(userInput.trim());
            
            if (storageAmount < 0) {
               JOptionPane.showMessageDialog(null, "Error. Please enter a positive number.");
            }
            else if (storageAmount > FileServers.MAX_STORAGE_IN_TB) {
               JOptionPane.showMessageDialog(null, "Error. Please enter a number between 0 and " + FileServers.MAX_STORAGE_IN_TB);
            }
            else {
               done = true;
            }
         }
         catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error. Please enter a number");
         }
         catch(NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error. Please enter a number");
         }
      }
      
      customerVM = new FileServers(storageType, storageMediaType, storageAmount);
      return customerVM;
   }
   
   /*
   Prompts the user for information on a bitcoin miner virtual machine. Prompts for information such as the number
   tof GPUs and the brand of the GPUs for a specific bitcoin miner virtual machine. With this information, a BitcoinMiners
   object will be instantiated.
   
   @return a BitcoinMiners object that represents a customer's bitcoin miner virtual machine.
   */
   public static BitcoinMiners getBitcoinMinerVMInfo() {
      BitcoinMiners customerVM = null;
      int numOfGPUs = 0;
      String gpuBrand = "";
      String userInput = "";
      final String[] GPU_BRANDS = {"AMD", "Nvidia"};
      boolean done = false;
      
      //Retrieve and validate number of GPUs
      while (!done) {
         userInput = JOptionPane.showInputDialog("How many GPUs will be needed for this Bitcoin Miner VM?");
         
         try {
            numOfGPUs = Integer.parseInt(userInput.trim());
            
            if (numOfGPUs < 1) {
               JOptionPane.showMessageDialog(null, "Error. Please enter a number greater than 0.");
            }
            else {
               done = true;
            }
         }
         catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error. Please enter a number.");
         }
         catch(NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error. Please enter a number.");
         }
      }
      
      done = false;
      
      String report = "";
      
      for (int i = 0; i < GPU_BRANDS.length; i++) {
         report += GPU_BRANDS[i] + "\n";
      }
      
      //Retrieve and validate GPU brand
      while (!done) {
         userInput = JOptionPane.showInputDialog("What brand of GPUs will be needed?\n\nAvailable Brands:\n" + report);
         
         switch (userInput.trim().toLowerCase()) {
            case "amd": gpuBrand = "AMD"; done = true; break;
            case "nvidia": gpuBrand = "Nvidia"; done = true; break;
            default: JOptionPane.showMessageDialog(null, "Error. Please choose from the following brands:\n" + report); break;
         }
      }
      
      customerVM = new BitcoinMiners(numOfGPUs, gpuBrand);
      return customerVM;
   }
   
   /*
   Prints a customer statistics report with information related to the number of customers with VMs, the total of monthly fees,
   the average of monthly fees, the amount of memory used by all VMs, the disk space used by all VMs, the number of GPUs used by
   VMs, and the number of bitcoin miner virtual machines.
   
   @param allCustomers an array that takes in customer information and the customer's associated virtual machine.
   */
   public static void printCustomerStatisticsReport(Customers[] allCustomers) {
      double totalMonthlyFees = 0;
      int numVMs = 0;
      int memoryUsed = 0;
      double diskSpaceUsed = 0;
      int gpusUsed = 0;
      String report;
      
      for (int i = 0; i < Customers.getNumOfCustomers(); i++) {
         totalMonthlyFees += allCustomers[i].getMonthlyFee();
         memoryUsed += allCustomers[i].getVMMemory();
         diskSpaceUsed += allCustomers[i].getVMDiskSpace();
         gpusUsed += allCustomers[i].getNumVMGPUs();
      }
      
      numVMs = WebServers.getNumWebServers() + FileServers.getNumFileServers() + BitcoinMiners.getNumBitcoinMiners();
      
      report = "Customer Statistics\n\n" +
               "Customers with VMs: " + numVMs +
               "\nTotal of Monthly Fees: $" + String.format("%.2f", totalMonthlyFees) +
               "\nAverage of Monthly Fees: $" + String.format("%.2f", totalMonthlyFees/Customers.getNumOfCustomers()) + 
               "\n\nMemory Used: " + memoryUsed + " GB";
               
      if (diskSpaceUsed >= 1000) {
         report += "\nDisk Space Used: " + (diskSpaceUsed / 1000.0) + " TB";
      }
      else {
         report += "\nDisk Space Used: " + diskSpaceUsed + " GB";
      }
      
      report += "\nGPUs Used: " + gpusUsed +
                "\nNumber of Bitcoin Miners: " + BitcoinMiners.getNumBitcoinMiners();
      
      JOptionPane.showMessageDialog(null, report);
   }
   
   /*
   Creates a printable roster in the form of a text file. It lists the total number of customers and all the customers' name with their customer IDs.
   
   @param allCustomers an array that takes in customer information and the customer's associated virtual machine.
   */
   public static void createPrintableRoster(Customers[] allCustomers) {      
      //Only create a roster if there is customer information
      if (Customers.getNumOfCustomers() != 0) {
         JOptionPane.showMessageDialog(null, "Please select a place to save the roster.");
      
         JFileChooser printableRosterFile = new JFileChooser();
         int saved = printableRosterFile.showSaveDialog(null);
                  
         //Check if the user choose a place to save the file before continuing
         if (saved == JFileChooser.APPROVE_OPTION) {
            String report = "Total Customers: " + Customers.getNumOfCustomers() + 
                            "\n\nCustomer ID | Customer Name";
         
            for (int i = 0; i < Customers.getNumOfCustomers(); i++) {
               report += "\n" + allCustomers[i].getID() + " | " + allCustomers[i].getName();
            }
         
            try {
               PrintWriter out = new PrintWriter(new FileOutputStream(new File(printableRosterFile.getSelectedFile().getPath())));
               
               out.print(report);
               out.close();
            }
            catch (FileNotFoundException e) {
               JOptionPane.showMessageDialog(null, "Error. Could not create the file.");
            }
         }
         else {
            JOptionPane.showMessageDialog(null, "Error. Could not create the file.");
         }
      }
      else {
         //There is no customer information
         JOptionPane.showMessageDialog(null, "There is no customer information. No roster will be created.");
      }
   }
}