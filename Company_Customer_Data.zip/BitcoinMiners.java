/*
Jessica Montoya
11/16/20
IT 206-202
Assignment 10
In this program, the user will input information for one or many customers and virtual machines for GMU Cloud. The information the user will input for a virtual machine
will vary depending on its type. The types include web servers, file servers, and bitcoin miners. For web server, the user will input information such as the amount of
additional memory the web server use. For file server, the user will input information such as the storage type, the storage media type, and the amount of additional storage
the file server will use. For bitcoin miner, the user will input information such as number of GPUs and the brand of the GPUs the bitcoin miner VM will use. The program uses
this information to create customer statistics and display the information in different ways. This program is designed to be flexible in terms of the max number of customers,
the charges for specific features, the starting amount of different resources. This flexibility was added in case changes needed to be done to the program in the future.
*/

public class BitcoinMiners extends VMs {
   private int numGPUs;
   private String gpuBrand;
   public static int numBitcoinMiners = 0;
   public static final double GPU_MONTHLY_COST = 10;
   public static final double NVIDIA_FLAT_MONTHLY = 15;
   
   /*
   Constructs a BitcoinMiners object with a specified number of GPUs and brand of GPUs for a bitcoin miner virtual machine.
   
   @param newNumGPUs an int that adds a specified number of GPUs to the file server virtual machine.
   @param newGPUBrand the string that will be given to a bitcoin miner virtual machine for its GPU brand.
   */
   public BitcoinMiners(int newNumGPUs, String newGPUBrand) {
      super();
      this.numGPUs = newNumGPUs;
      this.gpuBrand = newGPUBrand;
   }
   
   /*
   Constructs a BitcoinMiners object by making a copy of another BitcoinMiners object.
   
   @param customerVM a BitcoinMiners object that will be used to obtain information for the BitcoinMiners object copy.
   */
   public BitcoinMiners(BitcoinMiners customerVM) {
      super();
      this.numGPUs = customerVM.getNumGPUs();
      this.gpuBrand = customerVM.getGPUBrand();
      numBitcoinMiners++;
   }
   
   /*
   When called it returns the number of GPUs used for that specific bitcoin miner virtual machine.
   
   @return an int that represents the number of GPUs used for that specific bitcoin miner virtual machine.
   */
   public int getNumGPUs() {
      return this.numGPUs;
   }
   
   /*
   When called it returns the brand of GPUs used for that specific bitcoin miner virtual machine.
   
   @return a String that represents the brand of GPUs used for that specific bitcoin miner virtual machine.
   */
   public String getGPUBrand() {
      return this.gpuBrand;
   }
   
   /*
   When called it returns the number of bitcoin miner virtual machines objects that have been created.
   
   @return an int that represents the number of bitcoin miner virtual machines objects that have been created.
   */
   public static int getNumBitcoinMiners() {
      return numBitcoinMiners;
   }
   
   /*
   When called it returns the monthly cost for that specific bitcoin miner virtual machine.
   
   @return a double that represents the monthly cost for that specific bitcoin miner virtual machine.
   */
   public double getMonthlyCost() {
      double cost = 0;
      
      if (this.gpuBrand.equals("Nvidia")) {
         cost = super.FLAT_MONTHLY_RATE + (this.numGPUs * GPU_MONTHLY_COST) + NVIDIA_FLAT_MONTHLY;
      }
      else {
         cost = super.FLAT_MONTHLY_RATE + (this.numGPUs * GPU_MONTHLY_COST);
      }
   
      return cost;
   }
   
   /*
   When called it returns the information related to that specific bitcoin miner virtual machine.
   
   @return a string that represents the information related to that specific bitcoin miner virtual machine.
   */ 
   public String toString() {
      String report = "VM Type: Bitcoin Miner" + 
                      "\nMemory: " + super.getMemory() +" GB";
                      
      if (super.getStorage() >= 1000) {
         report += "\nSSD Storage: " + (super.getStorage() / 1000.0) + " TB";
      }
      else {
         report += "\nSSD Storage: " + super.getStorage() + " GB";
      }
      
      report += "\nNumber of GPUs: " + this.numGPUs +
                "\nBrand of GPUs: " + this.gpuBrand +
                "\nMonthly Cost: $" + String.format("%.2f", this.getMonthlyCost());
   
      return report;
   }
}