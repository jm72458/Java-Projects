/*
Jessica Montoya
11/2/20
IT 206-202
Assignment 8
In this program, the user will input information for one or many billable items for a consulting firm. The information the user will input for a billable item will vary depending on its type.
The types include service hours, personal car mileage, and ride service. For service hours, the user will input information such as hours worked and hourly rate. For personal car mileage, the
user will input information such as the distance travelled and the employees who were passengers in the same car. For ride service, the user will input information such as the price for the
ride and the service name. The program uses this information to create a list of billable items and display them in different ways. This program is designed to be flexible in terms of the number
of employees who work in the consulting firm. This flexibility was added in case changes needed to be done to the program in the future.
*/

public class PersonalCarMileage extends BillableItems {
   private double distance;
   private String[] passengers;
   public final double BILLED_RATE = 1;
   
   /*
   Constructs a billable personal car mileage item with a specified employee, day of the week, distance travelled, and
   employee passengers in the car.
   
   @param newEmployee the string that will be given to a billable personal car mileage item for its associated employee.
   @param newDay the string that will be given to a billable personal car mileage item for the day of the week the charge was incurred.
   @param newDistance the double that will be given to a billable personal car mileage item for its distance travelled.
   @param newPassengers the string array that will be given to a billable personal car mileage item for its employee passengers.
   */
   public PersonalCarMileage(String newEmployee, String newDay, double newDistance, String[] newPassengers) {
      super(newEmployee, newDay);
      
      if (newDistance > 0.0) {
         this.distance = newDistance;
      }
      
      if (newPassengers != null) {
         String[] addPassengers = new String[newPassengers.length];
      
         for (int i = 0; i < newPassengers.length; i++) {
            addPassengers[i] = newPassengers[i];
         }
      
         boolean valid = true;
         
         for (int i = 0; i < addPassengers.length; i++) {
            if (addPassengers[i].trim().equals("") || addPassengers[i].equals(" ")) {
               valid = false;
            }
         }
         
         if (valid) {
            this.passengers = addPassengers;
         }
      }
      else {
         this.passengers = null;
      }
   }
   
   /*
   When called it returns the distance travelled for that specific billable personal car mileage item.
   
   @return a double that represents the distance travelled for that specific billable personal car mileage item.
   */
   private double getDistance() {
      return this.distance;
   }
   
   /*
   When called it returns the employee passengers in the car for that specific billable personal car mileage item.
   
   @return a string array that represents the employee passengers in the car for that specific billable personal car mileage item.
   */
   public String[] getCarpooled() {
      String[] names = null;
      
      if (this.passengers != null) {
         names = new String[passengers.length];
         for (int i = 0; i < passengers.length; i++) {
         names[i] = passengers[i];
         }
      }
      
      return names;
   }
   
   /*
   When called it returns the billing charges for that specific billable personal car mileage item. It does
   this by multipling distance travelled and billed rate. It also rounds the result.
   
   @return an int that represents the billing charges for that specific billable personal car mileage item.
   */
   public int getBillingCharges() {
      int charge = 0;
      
      //Check if it needs to be rounded
      if ((int)(this.distance) == this.distance) {
         charge = (int)(this.distance * BILLED_RATE);
      }
      else {
         charge = (int)(BILLED_RATE * (int)(this.distance + 0.5));
      }
    
      return charge;   
   }
   
   /*
   When called it will test an object to determine if it is equal to another PersonalCarMileage object.
   
   @param test the object that will be tested against another PersonalCarMileage object.
   
   @return a boolean that represents whether or not the object being tested is equal to another PersonalCarMileage object
   */
   public boolean equals(Object test) {
      boolean valid = false;
      
      if (test != null && test.getClass() == getClass()) {
         PersonalCarMileage testObject = (PersonalCarMileage) test;
         if (this.distance == testObject.getDistance()) {
            valid = true;
            String[] testPassengers = testObject.getCarpooled();
            
            if (this.passengers.length == testPassengers.length) {
               for (int i = 0; i < this.passengers.length; i++) {
                  if (passengers[i] != testPassengers[i]) {
                     valid = false;
                  }
               }
            }
            else {
               valid = false;
            }
         }
      }
      
      return valid;
   }
   
   /*
   When called it returns the billable charges, the day of the week the billable was incurred, name of the associated employee, the distance travelled,
   and the employee passengers for that specific billable personal car mileage item.
   
   @return a string that represents the billable charges, the day of the week the billable was incurred, name of the associated employee, the distance travelled,
   the employee passengers, and the billable item type for that specific billable personal car mileage item.
   */
   public String toString() {
      String report = "$" + this.getBillingCharges() + ", " + super.getDay() + ", " + super.getEmployee().toUpperCase();
   
      if (this.passengers != null){
         report += " (";
         for (int i = 0; i < this.passengers.length; i++) {
            if (i == 0) {
               report += this.passengers[i].toUpperCase();
            }
            else {
               report += ", " + this.passengers[i].toUpperCase();
            }
         }
         
         report += "), Mileage";
      }
      else {
         report += ", Mileage";
      }
      
      return report;
   }
}