/*
Jessica Montoya
11/2/20
IT 206-202
Assignment 8
In this program, the user will input information for one or many billable items for a consulting firm. The information the user will input for a billable item will vary depending on its type.
The types include service hours, personal car mileage, and ride service. For service hours, the user will input information such as hours worked and hourly rate. For personal car mileage, the
user will input information such as the distance travelled and the employees who were passengers in the same car. For ride service, the user will input information such as the price for the
ride and the service name. The program uses this information to create a list of billable items and display them in different ways. This program is designed to be flexible in terms of the number
of employees who work in the consulting firm. This flexibility was added in case changes needed to be done to the program in the future.
*/

public class RideService extends BillableItems {
   private double price;
   private String serviceName;
   
   /*
   Constructs a billable ride service item with a specified employee, day of the week, price, and service name.
   
   @param newEmployee the string that will be given to a billable ride service item for its associated employee.
   @param newDay the string that will be given to a billable ride service item for the day of the week the charge was incurred.
   @param newPrice the double that will be given to a billable ride service item for its price.
   @param newServiceName the string that will be given to a billable ride service item for its service name.
   */
   public RideService(String newEmployee, String newDay, double newPrice, String newServiceName) {
      super(newEmployee, newDay);
      
      if (newPrice > 0.0) {
         this.price = newPrice;
      }
      
      if (!newServiceName.trim().equals("") && !newServiceName.equals(" ")) {
         this.serviceName = newServiceName;
      }
   }
   
   /*
   When called it returns the price for that specific billable ride service item.
   
   @return a double that represents the price for that specific billable ride service item.
   */
   private double getPrice() {
      return this.price;
   }
   
   /*
   When called it returns the service name for that specific billable ride service item.
   
   @return a string that represents the service name for that specific billable ride service item.
   */
   private String getServiceName() {
      return this.serviceName;
   }
   
   /*
   When called it returns the billing charges for that specific billable ride service item. It does this
   by rounding the price.
   
   @return an int that represents the billing charges for that specific billable ride services item.
   */
   public int getBillingCharges() {
      int charge = 0;
      
      //Check if needs to be rounded
      if ((int)(this.price) == this.price) {
         charge = (int)(this.price);
      }
      else {
         charge = (int)(this.price + 0.5);
      }
    
      return charge;   
   }
   
   /*
   When called it will test an object to determine if it is equal to another RideService object.
   
   @param test the object that will be tested against another RideService object.
   
   @return a boolean that represents whether or not the object being tested is equal to another RideService object
   */
   public boolean equals(Object test) {
      boolean valid = false;
      
      if (test != null && test.getClass() == getClass()) {
         RideService testObject = (RideService) test;
         if (this.price == testObject.getPrice() && this.serviceName == testObject.getServiceName()) {
            valid = true;
         }
      }
      
      return valid;
   }

   /*
   When called it returns the billable charges, the day of the week the billable was incurred, name of the associated employee, and the service
   name for that specific billable ride service item.
   
   @return a string that represents the billable charges, the day of the week the billable was incurred, name of the associated employee, and the service
   name for that specific billable ride service item.
   */
   public String toString() {
      return "$" + this.getBillingCharges() + ", " + super.getDay() + ", " + super.getEmployee().toUpperCase() + ", " + this.serviceName;
   }
}