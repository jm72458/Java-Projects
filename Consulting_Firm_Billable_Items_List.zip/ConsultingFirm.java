/*
Jessica Montoya
11/2/20
IT 206-202
Assignment 8
In this program, the user will input information for one or many billable items for a consulting firm. The information the user will input for a billable item will vary depending on its type.
The types include service hours, personal car mileage, and ride service. For service hours, the user will input information such as hours worked and hourly rate. For personal car mileage, the
user will input information such as the distance travelled and the employees who were passengers in the same car. For ride service, the user will input information such as the price for the
ride and the service name. The program uses this information to create a list of billable items and display them in different ways. This program is designed to be flexible in terms of the number
of employees who work in the consulting firm. This flexibility was added in case changes needed to be done to the program in the future.
*/

import javax.swing.JOptionPane;

public class ConsultingFirm {
   public static void main(String[] args){
      final int NUM_OF_EMPLOYEES = 5;
      final int MAX_BILLABLES = 999;
      
      String[] allEmployees = new String[NUM_OF_EMPLOYEES];
      BillableItems[] allBillableItems = new BillableItems[MAX_BILLABLES];
      
      promptUser(allEmployees, allBillableItems);
   }

   /*
   Continuously prompts the user for a menu option that can add a new billable item, display all billable items,
   display all billable items that are related to service hours, display employees who have participated in a carpool,
   or exit the program. The user decides when the prompting should stop.
   
   @param allEmployees an array that takes in employee names to associate them with billable items.
   @param allBillableitems an array of objects that takes in billable item information and displays the information in a certain format.
   */
   public static void promptUser(String[] allEmployees, BillableItems[] allBillableItems){
      boolean done = false;
      String userInput = "";
      
      while (!done) {
         userInput = JOptionPane.showInputDialog("1) Quit\n2) Add a Billable Item\n3) Display all Billable Items\n4) Display the Total for Billable Service (no travel)\n5) Display Employees who have carpooled (drivers included)\n\nEnter 1-5 for your selection.");
         
         switch (userInput.trim()) {
            case "1": JOptionPane.showMessageDialog(null, "Thank you for using this program!"); done = true; break;
            case "2": addBillableItem(allEmployees, allBillableItems); break;
            case "3": displayAllBillableItems(allBillableItems); break;
            case "4": displayBillableServicesTotal(allBillableItems); break;
            case "5": displayCarpooledEmployees(allBillableItems); break;
            default: JOptionPane.showMessageDialog(null, "Error. Please enter a number from 1 to 5 (inclusive)"); break;
         }
      }
   }
   
   /*
   Prompts the user for information on a billable. Prompts for information such as the billable item type, 
   the associated employee, and the day of the week. After it collects this information, it calls another method
   based on the billable type to prompt for the information associated with that type.
   
   @param allEmployees an array that takes in employee names to associate them with billable items.
   @param allBillableitems an array of objects that takes in billable item information and displays the information in a certain format.
   */
   public static void addBillableItem(String[] allEmployees, BillableItems[] allBillableItems) {
      final String[] DIFFERENT_BILLABLES = {"Service Hours", "Personal Car Mileage", "Ride Service"};
      boolean done = false;
      boolean execute = true;
      String userInput = "";
      int itemType = -1;
      String report = "";
      
      for (int i = 0; i < DIFFERENT_BILLABLES.length; i++) {
         report += (i+1) + ") " + DIFFERENT_BILLABLES[i] + "\n";
      }
      
      //Making sure the user does not enter more than the allBillableItems array size
      if (BillableItems.getNumBillableItems() == allBillableItems.length) {
         JOptionPane.showMessageDialog(null, "Error. Cannot add another billable item. Max billable items reached");
         execute = false;
      }
      
      if (execute) {
         //Getting the billable item type
         while (!done) {
            userInput = JOptionPane.showInputDialog(report + "\nWhich billable item would you like to add?");
         
            //Validating billable item type
            try {
               itemType = (Integer.parseInt(userInput) - 1);
            
               if (itemType < 0 || itemType >= DIFFERENT_BILLABLES.length) {
                 JOptionPane.showMessageDialog(null, "Error. Please enter a number from 1 to " + DIFFERENT_BILLABLES.length);
               }
               else {
                  done = true;
               }
            }  
            catch (NumberFormatException e) {
               JOptionPane.showMessageDialog(null, "Error. Please enter a number.");
               done = false;
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Error. Cannot be left blank. Please enter a number.");
               done = false;
            }
         }
      
         done = false;
         String employee = "";
         boolean newEmployee = true;
      
         //Getting the employee
         while (!done) {
            employee = JOptionPane.showInputDialog("What is the name of the employee in which this billable item relates to?");
         
            //Validating employee
            if (employee.trim().equals("") || employee.equals(" ")) {
               JOptionPane.showMessageDialog(null, "Error. Please enter a name.");
            }
            //If the user entered a name and the name is not empty
            else {
               employee = (employee.substring(0,1).toUpperCase() + employee.substring(1, employee.length()).toLowerCase());
            
               //If the user entered a name before check to see if it is new or not
               if (allEmployees[0] != null) {
                  for (int i = 0; i < allEmployees.length; i++) {
                     if (allEmployees[i] != null) {
                        if (employee.equals(allEmployees[i])) {
                           newEmployee = false;
                           done = true;
                        }
                     }
                  }
               
                  if (newEmployee) {
                     if (allEmployees[allEmployees.length - 1] != null) {
                        report = "Error. Employee name not valid. There are " + allEmployees.length + " employees.\nYou are attempting to add an extra employee.\n\nNames of Employees:\n";
                     
                        //Get the list of employees to remind the user which employees they have already entered      
                        for (int i = 0; i < allEmployees.length; i++) {
                           if (allEmployees[i] != null) {
                              report += allEmployees[i] + "\n";
                           }
                        }
                           
                        JOptionPane.showMessageDialog(null, report);
                     }
                     else {
                        for (int i = 0; i < allEmployees.length; i++) {
                           if (allEmployees[i] == null && !done) {
                              allEmployees[i] = employee;
                              done = true;
                           }
                        } 
                     }
                  }
               }
               //Add the name without checking because no employees have been entered yet
               else {
                  allEmployees[0] = employee;
                  done = true;
               }
            }
         }
   
      
         done = false;
         final String[] VALID_DAYS = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
         String day = "";
      
         //Getting the day of the week when the charge was incurred 
         while (!done) {
            day = JOptionPane.showInputDialog("Which day of the week was the charge incurred?");
         
            //Check if the user entered a value or not
            if (!day.trim().equals("") && !day.equals(" ")) {
               day = day.substring(0,1).toUpperCase() + day.substring(1, day.length()).toLowerCase();
         
               //Validating day
               for (int i = 0; i < VALID_DAYS.length; i++) {
                  if (day.equalsIgnoreCase(VALID_DAYS[i])) {
                     done = true;
                  }
               }
         
               if (!done) {
                  JOptionPane.showMessageDialog(null, "Error. Not a valid day.");
               }
            }
            //Send an error message for not entering a value
            else {
               JOptionPane.showMessageDialog(null, "Error. Please enter a day.");
            }
         }
      
         //Adding Service Hours Billage Item
         if (itemType == 0) {
            recordBillableServiceHours(employee, allBillableItems, day);
         }
         //Adding Personal Car Mileage Billage Item
         else if(itemType == 1) {
            recordBillablePersonalCarMileage(employee, allEmployees, allBillableItems, day);
         }
         //Adding Ride Service Billage Item
         else {
            recordBillableRideService(employee, allBillableItems, day);
         }
      }
   }
   
   /*
   Prompts the user for information on billable service hours. Prompts for information such as the hours worked and 
   hourly rate. With this information, a ServiceHours object will be instantiated.
   
   @param selectedEmployee a string that contains the name of the employee the user has choosen.
   @param allBillableitems an array of objects that takes in billable item information and displays the information in a certain format.
   @param day a string that contains the day of the week in which the charge was incurred.
   */
   public static void recordBillableServiceHours(String selectedEmployee, BillableItems[] allBillableItems, String day) {
      boolean done = false;
      String userInput;
      int hoursWorked = -1;
      
      //Get hours worked
      while (!done) {
         userInput = JOptionPane.showInputDialog("What is the number of hours " + selectedEmployee + " worked?");
         
         //Validate hours worked
         try {
            hoursWorked = Integer.parseInt(userInput);
            
            if (hoursWorked <= 0) {
               JOptionPane.showMessageDialog(null, "Error. Please enter a number greater than zero.");
            }
            else {
               done = true;
            }
         }
         catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error. Please enter a number.");
         }
         catch(NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error. Cannot be left blank. Please enter a number.");
         }
      }
      
      double hourlyRate = -1;
      done = false;
      
      //Get hourly rate
      while (!done) {
         userInput = JOptionPane.showInputDialog("What is the hourly rate for " + selectedEmployee + "?");
         
         //Validate hourly rate
         try {
            hourlyRate = Double.parseDouble(userInput);
            
            if (hourlyRate <= 0) {
               JOptionPane.showMessageDialog(null, "Error. Please enter a number greater than zero.");
            }
            else {
               done = true;
            }
         }
         catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error. Please enter a number.");
         }
         catch(NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error. Cannot be left blank. Please enter a number.");
         }
      }
      
      BillableItems newItem = new ServiceHours(selectedEmployee, day, hoursWorked, hourlyRate);
      allBillableItems[BillableItems.getNumBillableItems() - 1] = newItem;
   }
   
   /*
   Prompts the user for information on billable personal car mileage. Prompts for information such as the distance travelled and 
   the employees who were passengers in the car. With this information, a PersonalCarMileage object will be instantiated.
   
   @param selectedEmployee a string that contains the name of the employee the user has choosen.
   @param allEmployees an array that takes in employee names to associate them with billable items.
   @param allBillableitems an array of objects that takes in billable item information and displays the information in a certain format.
   @param day a string that contains the day of the week in which the charge was incurred.
   */
   public static void recordBillablePersonalCarMileage(String selectedEmployee, String[] allEmployees, BillableItems[] allBillableItems, String day) {
      final int MAX_PASSENGER_CAPACITY = 3;
      String[] employeesInCar = null;
      final double billedDistanceRate = 1;
      boolean done = false;
      boolean moveOn = false;
      String userInput;
      double distance = -1;
      
      //Getting the distance travelled
      while (!done) {
         userInput = JOptionPane.showInputDialog("What is the distance that was travelled?");
         
         //Validating the distance travelled
         try {
            distance = Double.parseDouble(userInput);
            
            if (distance <= 0) {
               JOptionPane.showMessageDialog(null, "Error. Please enter a number greater than zero.");
            }
            else {
               done = true;
            }
         }
         catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error. Please enter a number.");
         }
         catch(NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error. Cannot be left blank. Please enter a number.");
         }
      }
      
      done = false;
      
      //Get employees in car
      while (!done) {
         while (!moveOn){
            userInput = JOptionPane.showInputDialog("Were there other employees in the car?");
         
            //Validating employees in car
            switch (userInput.trim().toLowerCase()) {
               case "n":
               case "no": done = true; moveOn = true; break;
               case "y":
               case "yes": moveOn = true; break;
               default: JOptionPane.showMessageDialog(null, "Error. Please answer yes or no.");
            }
         }
                  
         //Run these statements when there are passengers in the car
         if (!done) {
            moveOn = false;
            int numEmployees = -1;
            
            while (!moveOn) {
               userInput = JOptionPane.showInputDialog("How many other employees were there?");
               
               //Validate number of employees
               try {
                  numEmployees = Integer.parseInt(userInput);
            
                  if (numEmployees <= 0) {
                     JOptionPane.showMessageDialog(null, "Error. Please enter a number greater than zero.");
                  }
                  else if (numEmployees > MAX_PASSENGER_CAPACITY) {
                     JOptionPane.showMessageDialog(null, "Error. Please enter a number from 1 to " + MAX_PASSENGER_CAPACITY);
                  }
                  else {
                     moveOn = true;
                  }
               }
               catch(NumberFormatException e) {
                  JOptionPane.showMessageDialog(null, "Error. Please enter a number.");
               }
               catch(NullPointerException e) {
                  JOptionPane.showMessageDialog(null, "Error. Cannot be left blank. Please enter a number.");
               }
            }
            
            int count = 1;
            String employee = "";
            boolean newEmployee = true;
            employeesInCar = new String[numEmployees];
            
            for (int i = 0; i < numEmployees; i++) {
               //Get employee that was a passenger
               moveOn = false;
               
               while (!moveOn) {
                  done = false;
                  newEmployee = true;
                  employee = JOptionPane.showInputDialog("What is the name of passenger " + (i+1) + "?");
                  
                  //Validate employee name
                  if (employee.trim().equals("") || employee.equals(" ")) {
                     JOptionPane.showMessageDialog(null, "Error. Please enter a name.");
                  }
                  //If the user entered a valid employee name
                  else {
                     employee = employee.substring(0,1).toUpperCase() + employee.substring(1, employee.length()).toLowerCase();
            
                     //If the user entered a name before check to see if it is new or not
                     for (int x = 0; x < allEmployees.length; x++) {
                        if (allEmployees[x] != null) {
                           if (employee.equals(allEmployees[x])) {
                              newEmployee = false;
                              moveOn = true;
                           }
                        }
                     }
               
                     if (newEmployee) {
                        if (allEmployees[allEmployees.length - 1] != null) {
                           String report = "Error. Employee name not valid. There are " + allEmployees.length + " employees.\nYou are attempting to add an extra employee.\n\nNames of Employees:\n";
                           
                           //Get list of employees the user has already entered
                           for (int x = 0; x < allEmployees.length; x++) {
                              if (allEmployees[x] != null) {
                                 report += allEmployees[x] + "\n";
                              }
                           }
                           
                           JOptionPane.showMessageDialog(null, report);
                        }
                        else {
                           for (int x = 0; x < allEmployees.length; x++) {
                              if (allEmployees[x] == null && !done) {
                                 allEmployees[x] = employee;
                                 done = true;
                                 moveOn = true;
                              }
                           } 
                        }
                     }
                     else {
                        if (employee.equals(selectedEmployee)) {
                           JOptionPane.showMessageDialog(null, "Error. This employee is the driver.");
                           moveOn = false;
                        }
                        else {
                           if (i > 0) {
                              for (int x = 0; x < i; x++) {
                                 if (employee.equals(employeesInCar[x])) {
                                    JOptionPane.showMessageDialog(null, "Error. This employee has already been labelled as a passenger.");
                                    moveOn = false;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
               
               employeesInCar[i] = employee;
            }
            
            done = true;
         }         
      }
            
      BillableItems newItem = new PersonalCarMileage(selectedEmployee, day, distance, employeesInCar);
      allBillableItems[BillableItems.getNumBillableItems() - 1] = newItem;
   }
   
   /*
   Prompts the user for information on billable ride services. Prompts for information such as the charge and 
   the service name. With this information, a RideService object will be instantiated.
   
   @param selectedEmployee a string that contains the name of the employee the user has choosen.
   @param allBillableitems an array of objects that takes in billable item information and displays the information in a certain format.
   @param day a string that contains the day of the week in which the charge was incurred.
   */
   public static void recordBillableRideService(String selectedEmployee, BillableItems[] allBillableItems, String day) {
      boolean done = false;
      String userInput;
      double charge = -1;
         
      //Get the charge
      while (!done) {
         userInput = JOptionPane.showInputDialog("How much was the charge?");
         
         //Validate the charge
         try {
            charge = Double.parseDouble(userInput);
            
            if (charge <= 0) {
               JOptionPane.showMessageDialog(null, "Error. Please enter a number greater than zero.");
            }
            else {
               done = true;
            }
         }  
         catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error. Please enter a number.");
            done = false;
         }
         catch (NullPointerException e) {
            JOptionPane.showMessageDialog(null, "Error. Cannot be left blank. Please enter a number.");
            done = false;
         }
      }
      
      done = false;   
      String serviceName = "";
      
      //Get the service name
      while (!done) {
         serviceName = JOptionPane.showInputDialog("What is the name of the service?");
         
         //Validate the service name
         if (!serviceName.trim().equals("") && !serviceName.equals(" ")) {
            serviceName = serviceName.substring(0,1).toUpperCase() + serviceName.substring(1, serviceName.length()).toLowerCase();
            done = true;
         }
         else {
            JOptionPane.showMessageDialog(null, "Error. Service name cannot be left blank. Please enter a service name.");
         }
      }
      
      BillableItems newItem = new RideService(selectedEmployee, day, charge, serviceName);
      allBillableItems[BillableItems.getNumBillableItems() - 1] = newItem;
   }
   
   /*
   Prints all billable item information with a total.
      
   @param allBillableitems an array of objects that takes in billable item information and displays the information in a certain format.
   */
   public static void displayAllBillableItems(BillableItems[] allBillableItems) {
      String report = "";
      int total = 0;
      final int TOTAL_BILLABLE = BillableItems.getNumBillableItems();
      String[] names = new String[TOTAL_BILLABLE];
      String[] days = new String[TOTAL_BILLABLE];
      int[] prices = new int[TOTAL_BILLABLE];
      boolean getPassengers = false;
      String[] carpoolNames;
      String carpoolDay;
      
      if (allBillableItems[0] != null) {
         for (int i = 0; i < names.length; i++) {            
            names[i] = allBillableItems[i].getEmployee();
            days[i] = allBillableItems[i].getDay();
            prices[i] = allBillableItems[i].getBillingCharges();
            
            if (allBillableItems[i] instanceof PersonalCarMileage && getPassengers == false) {
               getPassengers = true;
               carpoolNames = new String[allBillableItems[i].getCarpooled().length];
            }
         }
         
         //Check to see if billable item can be billed for travel. Will not bill if they were passenger in another car on the same day
         if (getPassengers) {
            for (int i = 0; i < names.length; i++) {
               if (allBillableItems[i] instanceof PersonalCarMileage) {
                  if (allBillableItems[i].getCarpooled() != null){
                     carpoolNames = allBillableItems[i].getCarpooled();
                     carpoolDay = allBillableItems[i].getDay();
                     for (int x = 0; x < carpoolNames.length; x++) {
                        for (int y = 0; y < names.length; y++) {
                           if (names[y].equals(carpoolNames[x]) && days[y].equals(carpoolDay)) {
                              if (allBillableItems[y] instanceof PersonalCarMileage || allBillableItems[y] instanceof RideService) {
                                 prices[y] = 0;
                              }
                           }
                        }
                     }
                  }
               }
            }
            
            for (int i = 0; i < names.length; i++) {
               if (prices[i] != 0) {
                  report += allBillableItems[i].toString() + "\n";
               }
               else {
                  report += "(Not Billable) " + allBillableItems[i].toString() + "\n";
               }
            }
         }
         //All billable items will be billed because there are no personal car mileage billable items
         else {
            for (int i = 0; i < names.length; i++) {
               report += allBillableItems[i].toString() + "\n";
            }
         }
         
         for (int i = 0; i < prices.length; i++) {
            total += prices[i];
         }
         
         report += "\n$" + total + " Total";
      }
      else {
         report = "No billable items to display.";
      }
      
      JOptionPane.showMessageDialog(null, report);
   }
   
   /*
   Prints all billable item information related to billable service hours. It also displays the total.
      
   @param allBillableitems an array of objects that takes in billable item information and displays the information in a certain format.
   */
   public static void displayBillableServicesTotal(BillableItems[] allBillableItems) {
      String report = "";
      int total = 0;
      int count = 0;
      
      if (allBillableItems[0] != null) {
         for (int i = 0; i < BillableItems.getNumBillableItems(); i++) {
            if (allBillableItems[i] instanceof ServiceHours) {
               report += allBillableItems[i].toString() + "\n";
               total += allBillableItems[i].getBillingCharges();
               count ++;
            }
         }
         
         if (count > 0) {
            report += "\n$" + total + " Total";
         }
         else {
            report = "No billable services to display.";
         }
      }
      else {
         report = "No billable services to display.";
      }
      
      JOptionPane.showMessageDialog(null, report);
   }
   
   /*
   Prints all employees that have carpooled in a car.
      
   @param allBillableitems an array of objects that takes in billable item information and displays the information in a certain format.
   */
   public static void displayCarpooledEmployees(BillableItems[] allBillableItems) {
      String report = "";
      int count = 0;
      final int POSSIBLE_CARPOOLERS = 3 * BillableItems.getNumBillableItems();
      String[] employeeNames = new String[POSSIBLE_CARPOOLERS];
      String[] passengers;
      boolean newEmployee = true;
      
      if (allBillableItems[0] != null) {
         for (int i = 0; i < BillableItems.getNumBillableItems(); i++) {
            if (allBillableItems[i] instanceof PersonalCarMileage) {
               if (allBillableItems[i].getCarpooled() != null) {
                  passengers = new String[allBillableItems[i].getCarpooled().length];
                  passengers = allBillableItems[i].getCarpooled();
                  
                  //Add employee names to the list without check because no employees have been listed yet
                  if (employeeNames[0] == null) {
                     //Add passengers
                     for (int x = 0; x < passengers.length; x++) {
                        employeeNames[x] = passengers[x];
                        count++;
                     }
                     
                     //Add driver
                     employeeNames[count] = allBillableItems[i].getEmployee();
                     count++;
                  }
                  //Check if there are duplicate names for employee carpoolers
                  else {
                     //Check duplicate passengers
                     for (int x = 0; x < passengers.length; x++) {
                        newEmployee = true;
                        
                        for (int y = 0; y < employeeNames.length; y++) {
                           if (passengers[x].equals(employeeNames[y])) {
                              newEmployee = false;
                           }
                        }
                     
                        if (newEmployee) {
                           employeeNames[count] = passengers[x];
                           count++;
                        }
                     }
                     
                     newEmployee = true;
                     
                     //Check for duplicate driver
                     for (int x = 0; x < employeeNames.length; x++) {
                        if (employeeNames[x] != null) {
                           if (employeeNames[x].equals(allBillableItems[i].getEmployee())) {
                              newEmployee = false;
                           }
                        }
                     }
                     
                     if (newEmployee) {
                        employeeNames[count] = allBillableItems[i].getEmployee();
                        count++;
                     }
                  }
               }
            }
         }
         
         //Check if any of the billable items are personal service mileage
         if (count > 0) {
            for (int i = 0; i < employeeNames.length; i++) {
               if (employeeNames[i] != null) {
                  if (i == 0) {
                     report += employeeNames[i];
                  }
                  else {
                     report += "\n" + employeeNames[i];
                  }
               }
            }
         }
         //If there are no billable items yet display this
         else {
            report = "No information to display.";
         }
      }
      else {
         report = "No information to display.";
      }
      
      JOptionPane.showMessageDialog(null, report);
   }
}