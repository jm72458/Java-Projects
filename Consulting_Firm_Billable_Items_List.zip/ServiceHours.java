/*
Jessica Montoya
11/2/20
IT 206-202
Assignment 8
In this program, the user will input information for one or many billable items for a consulting firm. The information the user will input for a billable item will vary depending on its type.
The types include service hours, personal car mileage, and ride service. For service hours, the user will input information such as hours worked and hourly rate. For personal car mileage, the
user will input information such as the distance travelled and the employees who were passengers in the same car. For ride service, the user will input information such as the price for the
ride and the service name. The program uses this information to create a list of billable items and display them in different ways. This program is designed to be flexible in terms of the number
of employees who work in the consulting firm. This flexibility was added in case changes needed to be done to the program in the future.
*/

public class ServiceHours extends BillableItems {
   private int hoursWorked;
   private double hourlyRate;
   
   /*
   Constructs a billable service hours item with a specified employee, day of the week, hours worked, and hourly rate.
   
   @param newEmployee the string that will be given to a billable service hours item for its associated employee.
   @param newDay the string that will be given to a billable service hours item for the day of the week the charge was incurred.
   @param newHoursWorked the int that will be given to a billable service hours item for its hours worked.
   @param newHourlyRate the double that will be given to a billable service hours item for its hourly rate.
   */
   public ServiceHours(String newEmployee, String newDay, int newHoursWorked, double newHourlyRate) {
      super(newEmployee, newDay);
      
      if (newHoursWorked > 0) {
         this.hoursWorked = newHoursWorked;
      }
      
      if (newHourlyRate > 0.0) {
         this.hourlyRate = newHourlyRate;
      }
   }
   
   /*
   When called it returns the hours worked for that specific billable service hours item.
   
   @return an int that represents the hours worked for that specific billable service hours item.
   */
   private int getHoursWorked() {
      return this.hoursWorked;
   }
   
   /*
   When called it returns the hourly rate for that specific billable service hours item.
   
   @return a double that represents the hourly rate for that specific billable service hours item.
   */
   private double getHourlyRate() {
      return this.hourlyRate;
   }
   
   /*
   When called it returns the billing charges for that specific billable service hours item. It does this
   by multipling hours worked and hourly rate. It also rounds the result.
   
   @return an int that represents the billing charges for that specific billable services hours item.
   */
   public int getBillingCharges() {
      int charge = 0;
      
      //Check if it needs to be rounded
      if ((int)(this.hourlyRate) == this.hourlyRate) {
         charge = (int)(this.hoursWorked * this.hourlyRate);
      }
      else {
         charge = (int)(this.hoursWorked * (int)(this.hourlyRate + 0.5));
      }
    
      return charge;
   }
   
   /*
   When called it will test an object to determine if it is equal to another ServiceHours object.
   
   @param test the object that will be tested against another ServiceHours object.
   
   @return a boolean that represents whether or not the object being tested is equal to another ServiceHours object
   */
   public boolean equals(Object test) {
      boolean valid = false;
      
      if (test != null && test.getClass() == getClass()) {
         ServiceHours testObject = (ServiceHours) test;
         if (this.hoursWorked == testObject.getHoursWorked() && this.hourlyRate == testObject.getHourlyRate()) {
            valid = true;
         }
      }
      
      return valid;
   }
   
   /*
   When called it returns the billable charges, the day of the week the billable was incurred, name of the associated employee, the billable item type,
   the number of hours worked, and the hourly rate for that specific billable service hours item.
   
   @return a string that represents the billable charges, the day of the week the billable was incurred, name of the associated employee, the number of hours worked,
   and the hourly rate for that specific billable service hours item.
   */
   public String toString() {
      return "$" + this.getBillingCharges() + ", " + super.getDay() + ", " + super.getEmployee().toUpperCase() + ", Service (" + (int)this.hoursWorked + " hours at $" + (int)(this.hourlyRate + 0.5) + " per hour)";
   }
}