/*
Jessica Montoya
11/2/20
IT 206-202
Assignment 8
In this program, the user will input information for one or many billable items for a consulting firm. The information the user will input for a billable item will vary depending on its type.
The types include service hours, personal car mileage, and ride service. For service hours, the user will input information such as hours worked and hourly rate. For personal car mileage, the
user will input information such as the distance travelled and the employees who were passengers in the same car. For ride service, the user will input information such as the price for the
ride and the service name. The program uses this information to create a list of billable items and display them in different ways. This program is designed to be flexible in terms of the number
of employees who work in the consulting firm. This flexibility was added in case changes needed to be done to the program in the future.
*/

public abstract class BillableItems {
   private String relatedEmployee;
   private String day;
   public static int numBillableItems = 0;
   
   /*
   Constructs a billable item with a specified employee and day of the week.
   
   @param newEmployee the string that will be given to a billable item for its associated employee.
   @param newDay the string that will be given to a billable item for the day of the week the charge was incurred.
   */
   public BillableItems(String newEmployee, String newDay) {
      if (!newEmployee.trim().equals("") && !newEmployee.equals(" ")){
         this.relatedEmployee = newEmployee;
         if (newDay.equals("Sunday") || newDay.equals("Monday") || newDay.equals("Tuesday") || newDay.equals("Wednesday") || newDay.equals("Thursday") || newDay.equals("Friday") || newDay.equals("Saturday")) {
            this.day = newDay;
            numBillableItems++;
         }
      }
   }
   
   /*
   When called it returns the name of the associated employee for that specific billable item.
   
   @return a string that represents the name of the associated employee.
   */
   public String getEmployee() {
      return this.relatedEmployee;
   }
   
   /*
   When called it returns the day of the week when the charge was incurred for that specific billable item.
   
   @return a string that represents the day of the week when the charge was incurred for a specific billable item.
   */
   public String getDay() {
      return this.day;
   }
   
   /*
   When called it returns the billing charges for that specific billable item.
   
   @return an int that represents the billing charges, rounded, for that specific billable item.
   */
   public abstract int getBillingCharges();
   
   /*
   When called it returns the names of the employees who were passengers in a car for that specific billable item.
   
   @return a string array that represents the names of the employees who were passengers in a car for that specific billable item.
   */
   public String[] getCarpooled() {
      return null;
   }
   
   /*
   When called it returns the number of billable items that have been entered by the user.
   
   @return an int that represents the number of billable items that have been entered by the user.
   */
   public static int getNumBillableItems() {
      return numBillableItems;
   }
   
   /*
   When called it will test an object to determine if it is equal to another object.
   
   @param test the object that will be tested against another object.
   
   @return a boolean that represents whether or not the object being tested is equal to another object
   */
   public abstract boolean equals(Object test);
   
   /*
   When called it returns the name of the associated employee and the day of the week the billable was incurred for that specific billable item.
   
   @return a string that represents the name of the associated employee and the day of the week the billable was incurred for that specific billable item.
   */
   public String toString() {
      return "Associated Employee: " + this.relatedEmployee + "\nDay: " + this.day;
   }
}