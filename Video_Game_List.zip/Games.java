/*
Jessica Montoya
9/28/20
IT 206-202
Assignment 4
In this program, the user will input information for one or many games. The information the user will input for a game will include its title, MSRP, rating, and release month.
The program uses this information to create a list of games that are schedule to release in the year 2021-22 for a company called Patriot Games. The games will appear the with
the values the user has assigned to it.
*/

public class Games {
   private String title;
   private double msrp;
   private String rating;
   private String month;
   private static int numOfGames = 0;
   
   /*
   Constructs a game with a specified title, MSRP, rating, and release month.
   
   @param newTitle the string that will be given to a game for its title.
   @param newMonth the string that will be given to a game for its release month.
   */
   public Games(String newTitle, String newMonth) {
      this.title = newTitle;
      this.month = newMonth;
      msrp = 0.0;
      rating = "";
      numOfGames++;
   }
   
   /*
   Constructs a game with a specified title, MSRP, rating, and release month.
   
   @param newTitle the string that will be given to a game for its title.
   @param newMonth the string that will be given to a game for its release month.
   @param newMSRP the number that will be given to a game for its MSRP.
   */
   public Games(String newTitle, String newMonth, double newMSRP) {
      this(newTitle, newMonth);
      this.msrp = newMSRP;
   }
   
   /*
   Constructs a game with a specified title, MSRP, rating, and release month.
   
   @param newTitle the string that will be given to a game for its title.
   @param newMonth the string that will be given to a game for its release month.
   @param newRating the string that will be given to a game for its rating.
   */
   public Games(String newTitle, String newMonth, String newRating) {
      this(newTitle, newMonth);
      this.rating = newRating;
   }
   
   /*
   Constructs a game with a specified title, MSRP, rating, and release month.
   
   @param newTitle the string that will be given to a game for its title.
   @param newMonth the string that will be given to a game for its release month.
   @param newMSRP the number that will be given to a game for its MSRP.
   @param newRating the string that will be given to a game for its rating.
   */
   public Games(String newTitle, String newMonth, double newMSRP, String newRating)        {
      this(newTitle, newMonth);
      this.msrp = newMSRP;
      this.rating = newRating;
   }
   
   /*
   When called it returns the number of games that are currently listed in the game release list.
   
   @return an int value that represents the number of games that are on the game release list.
   */
   public static int getNumOfGames() {
      return numOfGames;
   }
   
   /*
   When called it returns the title of that specific game.
   
   @return an string that represents the title of a game.
   */
   public String getTitle() {
      return this.title;
   }
   
   /*
   When called it returns the MSRP of that specific game.
   
   @return an number that represents the MSRP of a game.
   */
   public double getMSRP() {
      return this.msrp;
   }
   
   /*
   When called it returns the rating of that specific game.
   
   @return an string that represents the rating of a game.
   */
   public String getRating() {
      return this.rating;
   }
   
   /*
   When called it returns the release month of that specific game.
   
   @return an string that represents the release month of a game.
   */
   public String getMonth() {
      return this.month;
   }
   
   /*
   When called it removes information on a specific game.
   */
   public void removeGame() {
      this.title = "";
      this.msrp = 0.0;
      this.rating = "";
      this.month = "";
      numOfGames--;
   }
   
   /*
   When called it changes the information for a specific game.
   
   @param newTitle a string that will change the title of a specific game.
   @param newMSRP a number that will change the MSRP of a specific game.
   @param newRating a string that will change the rating of a specific game.
   @param newMonth a string that will change the release month of a specific game.
   */
   public void updateGame(String newTitle, double newMSRP, String newRating, String newMonth) {
      this.title = newTitle;
      this.msrp = newMSRP;
      this.rating = newRating;
      this.month = newMonth;
   }
   
   /*
   When called it displays information on a game's title, MSRP, rating, and release month for a specific game.
   
   @return an string that displays information on a game's title, MSRP, rating, and release month for a specific game.
   */
   public String toString() {
      String report = "";
      //Report for no MSRP and no rating.
      if (this.msrp == 0.0 && (this.rating.equalsIgnoreCase("") || this.rating.equalsIgnoreCase(null))) {
         report = "Title: " + this.title +
                         "\nMSRP: No listed MSRP" +
                         "\nRating: Not rated" +
                         "\nRelease Month: " + this.month;
      }
      //Report for no MSRP and has a rating.
      else if (this.msrp == 0.0 && (!(this.rating.equalsIgnoreCase("") || this.rating.equalsIgnoreCase(null)))) {
         report = "Title: " + this.title +
                         "\nMSRP: No listed MSRP" +
                         "\nRating: " + this.rating +
                         "\nRelease Month: " + this.month;
      }
      //Report that has a MSRP and no rating.
      else if (this.msrp > 0 && (this.rating.equalsIgnoreCase("") || this.rating.equalsIgnoreCase(null))) {
         report = "Title: " + this.title +
                         "\nMSRP: " + this.msrp +
                         "\nRating: Not rated" +
                         "\nRelease Month: " + this.month;
      }
      //Report that has a MSRP and a rating.
      else {
         report = "Title: " + this.title +
                         "\nMSRP: " + this.msrp +
                         "\nRating: " + this.rating +
                         "\nRelease Month: " + this.month;
      }
      
      return report;
   }
}