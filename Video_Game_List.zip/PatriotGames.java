/*
Jessica Montoya
9/28/20
IT 206-202
Assignment 4
In this program, the user will input information for one or many games. The information the user will input for a game will include its title, MSRP, rating, and release month.
The program uses this information to create a list of games that are schedule to release in the year 2021-22 for a company called Patriot Games. The games will appear the with
the values the user has assigned to it.
*/

import javax.swing.JOptionPane;

public class PatriotGames {

   //This method calls a different method to collect information on games.
   public static void main (String[] args){
      final int maxGames = 36;
      Games[] scheduledGames = new Games[maxGames];
      
      promptUser(scheduledGames, maxGames);  
   }
   
   /*
   Continuously prompts the user for a menu option that can add new game information, remove game information, update game information, display game information by month,
   display all game information, or exit the program. The user decides when the prompting should stop
   
   @param scheduledGames an object array that takes in game information to display in the game release list.
   @param maxGames an int value that keeps track of the max games that should be allowed at once on the games release list
   */
   public static void promptUser(Games[] scheduledGames, int maxGames){
      int userOption = 0;
      boolean done = false;
      
      //Constantly prompts user with the menu until the user ends the prompting
      while (userOption == 0 || done == false) {
         try {
            userOption = Integer.parseInt(JOptionPane.showInputDialog("Choose from the following options:\n\n" +
                         "1. Add Game to the Release Schedule\n" +
                         "2. Remove Game from Release Schedule\n" + 
                         "3. Update A Game Schedule\n" +
                         "4. Print Games by a Given Month\n" +
                         "5. Print Entire Release Schedule\n" +
                         "6. Exit the program\n\n"));
         }
         catch (NumberFormatException e) {
            userOption = 0;
         }
         catch (NullPointerException e) {
            userOption = 0;
         }
         
         //Validating if the user entered a number from 1 to 6 which represents one of the options in the menu
         if (userOption > 6 || userOption < 1) {
            JOptionPane.showMessageDialog(null, "Please enter a number from 1 to 6");
            userOption = 0;
         }
         else {
            int gameIndex = 0;
            String menuTitle = "";
            String title = "";
            double msrp = 0.0;
            String rating = "";
            String month = "";
            String report = "";
            
            //Dealing with the option the user choose
            switch (userOption) {
               //Add Game to the Release Schedule
               case 1: 
                     if (Games.getNumOfGames() == maxGames) {
                        JOptionPane.showMessageDialog(null, "There is already a max of " + maxGames + " games scheduled for the calender year 2021-2022. Cannot add a new game");
                     }
                     else {
                        menuTitle = "Add Game to the Release Schedule";
                        title = promptTitle(menuTitle);
                        msrp = promptMSRP(menuTitle);
                        rating = promptRating(menuTitle);
                        month = promptMonth(menuTitle);
                     
                        //Send the information to the Game class
                        gameIndex = Games.getNumOfGames();
                        //No MSRP and no rating
                        if (msrp == 0 && (rating.equalsIgnoreCase("") || rating.equalsIgnoreCase(null))) {
                           scheduledGames[gameIndex] = new Games(title, month);
                        }
                        //A MSRP and no rating
                        else if (msrp > 0 && (rating.equalsIgnoreCase("") || rating.equalsIgnoreCase(null))) {
                           scheduledGames[gameIndex] = new Games(title, month, msrp);
                        }
                        //No MSRP and a rating
                        else if (msrp == 0 && (!(rating.equalsIgnoreCase("") || rating.equalsIgnoreCase(null)))) {
                           scheduledGames[gameIndex] = new Games(title, month, rating);
                        }
                        //A MSRP and a rating
                        else {
                           scheduledGames[gameIndex] = new Games(title, month, msrp, rating);
                        }
                     }
                     break;
                     
               //Remove Game from Release Schedule
               case 2:
                     if (Games.getNumOfGames() > 0) {
                        report = "Remove Game from Release Schedule:\n";
                        int game = -1;
                     
                        for (int i = 0; i < Games.getNumOfGames(); i++) {
                           report += "\nGame #" + (i + 1) + ":\n" + scheduledGames[i].toString() + "\n";
                        }
                     
                        while (game == -1) {
                           try {
                              game = Integer.parseInt(JOptionPane.showInputDialog(report + "\nSelect a game (Use game number)"));
                              
                              if (game < 1 || game > Games.getNumOfGames()) {
                                 JOptionPane.showMessageDialog(null, "Remove Game from Release Schedule:\n\nPlease enter a number from 1 to " + Games.getNumOfGames());
                                 game = -1;
                              }
                           }
                           catch (NullPointerException e) {
                              JOptionPane.showMessageDialog(null, "Remove Game from Release Schedule:\n\nPlease enter a number");
                              game = -1;
                           }
                           catch(NumberFormatException e) {
                              JOptionPane.showMessageDialog(null, "Remove Game from Release Schedule:\n\nPlease enter a number");
                              game = -1;
                           }
                        }
                     
                        scheduledGames[game - 1].removeGame();
                        fixGameOrder(scheduledGames);
                     }
                     else {
                        JOptionPane.showMessageDialog(null, "There are no scheduled games");
                     }
                     break;
                   
               //Update A Game Schedule  
               case 3:
                     if (Games.getNumOfGames() > 0) {
                        menuTitle = "Update A Game Schedule";
                        report = menuTitle + ":\n";
                        int game = -1;
                     
                        for (int i = 0; i < Games.getNumOfGames(); i++) {
                           report += "\nGame #" + (i + 1) + ":\n" + scheduledGames[i].toString() + "\n";
                        }
                     
                        while (game == -1) {
                           try {
                              game = Integer.parseInt(JOptionPane.showInputDialog(report + "\nSelect a game (Use game number)"));
                              
                              if (game < 1 || game > Games.getNumOfGames()) {
                                 JOptionPane.showMessageDialog(null, menuTitle + ":\n\nPlease enter a number from 1 to " + Games.getNumOfGames());
                                 game = -1;
                              }
                           }
                           catch (NullPointerException e) {
                              JOptionPane.showMessageDialog(null, menuTitle + ":\n\nPlease enter a number");
                              game = -1;
                           }
                           catch(NumberFormatException e) {
                              JOptionPane.showMessageDialog(null, menuTitle + ":\n\nPlease enter a number");
                              game = -1;
                           }
                        }
                     
                        title = promptTitle(menuTitle);
                        msrp = promptMSRP(menuTitle);
                        rating = promptRating(menuTitle);
                        month = promptMonth(menuTitle);
                     
                        scheduledGames[game - 1].updateGame(title, msrp, rating, month);
                     }
                     else {
                        JOptionPane.showMessageDialog(null, "There are no games scheduled");
                     }
                     break;
                     
               //Print Games by a Given Month
               case 4:
                     if (Games.getNumOfGames() > 0) {
                        menuTitle = "Print Games by a Given Month";
                        month = promptMonth(menuTitle);
                     
                        report = menuTitle + "\n";
                        int count = 1;
                        for (int i = 0; i < Games.getNumOfGames(); i++) {
                           if (scheduledGames[i].getMonth().equalsIgnoreCase(month)) {
                              report += "\nGame #" + count + ":\n" + scheduledGames[i] + "\n";
                              count++;
                           }
                        }
                        
                        if (count > 1) {
                           JOptionPane.showMessageDialog(null, report);
                        }
                        else {
                           JOptionPane.showMessageDialog(null, "There are no games with that scheduled month");
                        }
                     }
                     else {
                        JOptionPane.showMessageDialog(null, "There are no games scheduled");
                     }
                     break;
                     
               //Print Entire Release Schedule
               case 5:
                     if (Games.getNumOfGames() > 0) {
                        menuTitle = "Print Entire Release Schedule";
                        report = menuTitle + "\n";
                        for (int i = 0; i < Games.getNumOfGames(); i++) {
                           report += "\nGame #" + (i + 1) + ":\n" + scheduledGames[i] + "\n";
                        }
                        
                        JOptionPane.showMessageDialog(null, report);
                     }
                     else {
                        JOptionPane.showMessageDialog(null, "There are no games scheduled");
                     }
                     break;
                     
               //Exit the program
               case 6: done = true; break;
            }
         }
      }
   }
   
   /*
   Prompts the user to enter a title for a game.
   
   @param menuTitle a string that displays the name of the menu option the user choose to make sure the user knows what the information is being used for.
   
   @return a string with a title that is acceptable
   */
   private static String promptTitle(String menuTitle) {
      String title = "";
                     
      //Validating title to make sure it is not null or empty
      while (title.equalsIgnoreCase("") || title.equalsIgnoreCase(null)) {
         title = JOptionPane.showInputDialog(menuTitle + ":\n\nEnter the title");
         if (title.equalsIgnoreCase("") || title.equalsIgnoreCase(null)) {
            JOptionPane.showMessageDialog(null, menuTitle + ":\n\nThe game must have a title. Please enter a title");
         }
      }
      
      //Setting title to title case
      String firstLetter = title.substring(0,1).toUpperCase();
      String restOfTitle = title.substring(1, title.length()).toLowerCase();
      title = firstLetter.concat(restOfTitle);
      title = title.trim();
      
      //If title is a phrase then captialize each word
      if (title.indexOf(' ') > -1) {
         String upperCharacter;
         String section = "";
         String newTitle = "";
         int lastIndex = -2;
         
         for (int i = 0; i < (title.length() - 1); i++) {
            if (title.charAt(i) == ' '){
               section = title.substring(lastIndex + 2, i + 1);
               upperCharacter = title.substring(i+1, i+2).toUpperCase();
               newTitle += section.concat(upperCharacter);
               lastIndex = i;
            }
         }
         
         if (lastIndex + 2 < title.length()) {
            section = title.substring(lastIndex + 2, title.length());
             newTitle = newTitle.concat(section);
         }
         
         title = newTitle;
      }
      
      return title;
   }
   
   /*
   Prompts the user to enter a MSRP for a game.
   
   @param menuTitle a string that displays the name of the menu option the user choose to make sure the user knows what the information is being used for.
   
   @return a double with a MSRP that is acceptable
   */
   private static double promptMSRP(String menuTitle) {
      String userInput = "";
      double msrp = -1;
   
      //Validating msrp and get the msrp if there is one
      while (msrp < 0.0) {
         try {
            userInput = JOptionPane.showInputDialog(menuTitle + ":\n\nEnter the msrp (Can be left blank)");
            
            //Make the msrp zero when the user decides not to enter a value
            if (userInput.equalsIgnoreCase("") || userInput.equalsIgnoreCase(null)) {
               msrp = 0.0;
            }
            else {
               msrp = Double.parseDouble(userInput);
            }
                          
            if (msrp < 0) {
               JOptionPane.showMessageDialog(null, menuTitle + ":\n\nPlease enter a number greater than 0");
            }
         } //Make the msrp zero when the user decides not to enter a value
         catch (NullPointerException e) {
            msrp = 0.0;
         }
         catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(null, menuTitle + ":\n\nPlease enter a number");
            msrp = -1;
         }
      }
      
      return msrp;
   }
   
   /*
   Prompts the user to enter a rating for a game.
   
   @param menuTitle a string that displays the name of the menu option the user choose to make sure the user knows what the information is being used for.
   
   @return a string with a rating that is acceptable
   */
   private static String promptRating(String menuTitle) {
      final String [] validRatings = {"Everyone", "Teen", "Mature"};
      String rating = "";
      boolean moveOn = false;
      
      while (!moveOn) {      
         //Geting the rating from the user
         rating = JOptionPane.showInputDialog(menuTitle + ":\n\nEnter a rating (Can be left blank)");
         moveOn = true;
         
         //Validate the rating if the user decides to add one
         if (!(rating.equalsIgnoreCase("") || rating.equalsIgnoreCase(null))) {
            boolean valid = false;
            for (int i = 0; i < validRatings.length; i++) {
               if (rating.equalsIgnoreCase(validRatings[i])) {
                  valid = true;
               }
            }
            
            if (!valid) {
               String report = menuTitle + "\n\nPlease enter one of the following ratings:";
               
               for (int i = 0; i < validRatings.length; i++) {
                  report += "\n" + validRatings[i];
               }
               
               JOptionPane.showMessageDialog(null, report);
               moveOn = false;
            }
         }
      
      }
      
      //Setting rating to title case
      if (!(rating.equalsIgnoreCase("") || rating.equalsIgnoreCase(null))) {
         String firstLetter = rating.substring(0,1);
         String restOfWord = rating.substring(1, rating.length()).toLowerCase();
         rating = firstLetter.toUpperCase() + restOfWord;
         rating.trim();
      }
      
      return rating;
   }
   
   /*
   Prompts the user to enter a release month.
   
   @param menuTitle a string that displays the name of the menu option the user choose to make sure the user knows what the information is being used for.
   
   @return a string with a month that is acceptable
   */
   private static String promptMonth(String menuTitle) {
      final String[] validMonths = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
      String month = "";
   
      //Validating month
      while (month.equalsIgnoreCase("") || month.equalsIgnoreCase(null)) {
         month = JOptionPane.showInputDialog(menuTitle + ":\n\nEnter a release month");
         if (month.equalsIgnoreCase("") || month.equalsIgnoreCase(null)) {
            JOptionPane.showMessageDialog(null, menuTitle + ":\n\nThere must be a release month. Please enter a month");
         }
         else {
            boolean valid = false;
            for (int i = 0; i < validMonths.length; i++) {
               if (month.equalsIgnoreCase(validMonths[i])) {
                  valid = true;
               }
            }
                           
            if (!valid) {
               String report = menuTitle + ":\n\nPlease enter one of the following month:";
                              
               for (int i = 0; i < validMonths.length; i++) {
                  report += "\n" + validMonths[i];
               }
                              
               JOptionPane.showMessageDialog(null, report);
               month = "";
            }
         }
      }
      
      //Setting month to title case
      String firstLetter = month.substring(0,1);
      String restOfWord = month.substring(1, month.length());
      month = firstLetter.toUpperCase() + restOfWord;
      month.trim();
      
      return month;
   }
   
   /*
   Fixes the game order when the game list has gaps from removing a game from the release list.
   
   @param allGames an object array that is used to send information to the data definition class on how to reorder the games in the array.
   */
   private static void fixGameOrder(Games[] allGames) {
      //Gets the game after an empty spot and moves it into an empty spot. Runs through until there are no more games to move in the list
      for (int i = 0; i < (Games.getNumOfGames() + 1); i++) {
         if (allGames[i].getTitle().equalsIgnoreCase("") || allGames[i].getTitle().equalsIgnoreCase(null)) {
            if (i != Games.getNumOfGames()){
               allGames[i].updateGame(allGames[i + 1].getTitle(), allGames[i + 1].getMSRP(), allGames[i + 1].getRating(), allGames[i + 1].getMonth());
               allGames[i + 1].updateGame("", 0.0, "", "");
            }
         }
      }
   }
}